import React, { useState } from 'react'
import { api, clock, fmtNum } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, Empty, EnvTag, ErrorNote, Json, Loading, PageHead, SevBadge } from '../components/ui'

export default function Rca() {
  const [selected, setSelected] = useState<string | null>(null)
  const { data, loading, reload } = useApi<any>('/api/aiops/correlations', [], 10000)
  const detail = useApi<any>(selected ? `/api/aiops/rca/${selected}` : null, [selected])

  if (loading) return <Loading rows={3} />
  const incs = data?.incidents || []
  React.useEffect(() => {
    if (!selected && incs.length) setSelected(incs[0].id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [incs.length])

  const d = detail.data
  return (
    <div>
      <PageHead eyebrow="Root Cause Analysis" title="Correlated incidents and causal chains"
        sub="Alerts are clustered by failure domain, ordered temporally, then matched to a root-cause signature with a confidence score. Every step is inspectable."
        right={<EnvTag />} />

      <div className="grid gap-4 lg:grid-cols-[340px_1fr]">
        <Card className="overflow-hidden">
          <CardHead title="Incidents" sub={`${incs.length} correlated clusters`} right={
            <button className="btn btn-xs" onClick={reload}>↻</button>} />
          <div className="max-h-[640px] divide-y divide-line/60 overflow-y-auto">
            {incs.length === 0 && <Empty text="No correlated incident yet. Trigger 'Multiple related alerts' in the demo drawer." />}
            {incs.map((i: any) => (
              <button key={i.id} onClick={() => setSelected(i.id)}
                className={`block w-full px-4 py-3 text-left transition-colors ${selected === i.id ? 'bg-sky/10' : 'hover:bg-white/[0.03]'}`}>
                <div className="flex items-center justify-between gap-2">
                  <span className="truncate text-[12px] font-medium text-slate-200">{i.title}</span>
                  <SevBadge severity={i.severity} />
                </div>
                <div className="mt-1 flex items-center gap-2 text-[10px] text-slate-500">
                  <span>{i.alerts} alerts</span><span>·</span>
                  <span>conf {(i.confidence * 100).toFixed(0)}%</span><span>·</span>
                  <span>{clock(i.opened_at)}</span>
                </div>
              </button>
            ))}
          </div>
        </Card>

        <div className="space-y-4">
          {detail.error && <ErrorNote message={detail.error} />}
          {!d && !detail.loading && <Card className="card-pad"><Empty text="Select an incident to inspect its causal chain." /></Card>}
          {d && (
            <>
              <Card className="card-pad">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="label">Root cause hypothesis</div>
                    <h2 className="mt-1 text-[17px] font-semibold text-white">{d.incident.root_cause}</h2>
                    <p className="mt-1 max-w-2xl text-[11.5px] leading-relaxed text-slate-400">{d.incident.summary}</p>
                  </div>
                  <div className="text-right">
                    <div className="label">Confidence</div>
                    <div className="text-[24px] font-semibold text-sky">{(d.incident.confidence * 100).toFixed(0)}%</div>
                    <span className="chip">{d.incident.status}</span>
                  </div>
                </div>
                <div className="mt-3 grid gap-2 sm:grid-cols-3">
                  {[['Opened', clock(d.incident.opened_at)], ['Owner', d.incident.owner], ['Method', 'affinity + temporal']].map(([k, v]) => (
                    <div key={k} className="rounded-lg border border-line bg-ink-900/60 px-3 py-2">
                      <div className="label">{k}</div>
                      <div className="mono mt-0.5 text-slate-300">{v}</div>
                    </div>
                  ))}
                </div>
              </Card>

              <div className="grid gap-4 lg:grid-cols-2">
                <Card>
                  <CardHead title="Causal timeline" sub="First breach to latest signal" />
                  <div className="p-5">
                    <div className="relative space-y-3 border-l border-line pl-4">
                      {d.timeline.map((t: any, i: number) => (
                        <div key={i} className="relative">
                          <span className="absolute -left-[21px] top-1 h-2 w-2 rounded-full" style={{ background: t.severity === 'critical' ? '#f43f5e' : '#f59e0b' }} />
                          <div className="mono text-[10px] text-slate-500">{clock(t.t)}</div>
                          <div className="text-[11.5px] text-slate-300">{t.event}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </Card>
                <Card>
                  <CardHead title="Recommended actions" sub="Ordered by blast-radius containment" />
                  <ol className="space-y-2 p-5">
                    {d.recommended_actions.map((a: string, i: number) => (
                      <li key={i} className="flex gap-2.5 rounded-lg border border-line bg-ink-900/60 px-3 py-2">
                        <span className="mono text-[10px] text-sky">{String(i + 1).padStart(2, '0')}</span>
                        <span className="text-[11.5px] leading-relaxed text-slate-300">{a}</span>
                      </li>
                    ))}
                  </ol>
                </Card>
              </div>

              <Card>
                <CardHead title="Contributing signals" sub="Per-alert explainability trace" />
                <div className="divide-y divide-line/60">
                  {d.alerts.map((a: any) => (
                    <div key={a.alert_id} className="px-5 py-3">
                      <div className="flex items-center justify-between">
                        <span className="text-[12px] font-medium text-slate-200">{a.metric}</span>
                        <span className="mono text-[10.5px] text-slate-500">{a.host}</span>
                      </div>
                      <div className="mt-1 text-[11px] text-slate-400">{a.value}</div>
                      <div className="mt-2 flex flex-wrap gap-1.5">
                        {a.signals.map((s: any, j: number) => (
                          <span key={j} className="chip">{s.name}: {String(s.value)} (w{s.weight})</span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </Card>
            </>
          )}
        </div>
      </div>
    </div>
  )
}
