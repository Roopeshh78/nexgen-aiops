import React from 'react'
import { fmtNum } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, EnvTag, ErrorNote, Kpi, Loading,
  PageHead, SevBadge, Table, Td } from '../components/ui'

export default function Anomalies() {
  const { data, error, loading } = useApi<any>('/api/aiops/anomalies', [], 8000)
  if (loading) return <Loading rows={4} />
  if (error) return <ErrorNote message={error} />
  const crit = data.anomalies.filter((a: any) => a.severity === 'critical').length
  const staleHosts = new Set(data.anomalies.filter((a: any) => a.stale).map((a: any) => a.host))

  return (
    <div>
      <PageHead eyebrow="Anomaly Detection" title="Deviation against learned baselines"
        sub={data.method}
        right={<><span className="chip border-rose/30 bg-rose/10 text-rose">{crit} critical</span><EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Anomalies surfaced" value={data.anomalies.length} accent="#38bdf8" icon="◈" hint="after baseline filtering" />
        <Kpi label="Critical deviations" value={crit} accent="#f43f5e" icon="⚠" hint="|z| ≥ 4 or threshold breach" />
        <Kpi label="Hosts affected" value={new Set(data.anomalies.map((a: any) => a.host)).size} accent="#f59e0b" icon="▤" hint="distinct hosts" />
        <Kpi label="Stale-flagged" value={staleHosts.size} accent="#8b5cf6" icon="⧗" hint="excluded from health claims" />
      </div>

      <Card className="mt-4">
        <CardHead title="Anomaly queue" sub="Sorted by severity, then absolute z-score" />
        <Table head={['Host', 'Metric', 'Value', 'Baseline μ', 'σ', 'Z-score', 'Deviation', 'Threshold', 'Severity']}>
          {data.anomalies.length === 0 && (
            <tr><Td className="text-slate-500">No deviation exceeds the detection threshold in the current window.</Td></tr>
          )}
          {data.anomalies.map((a: any, i: number) => (
            <tr key={i} className="row-hover">
              <Td className="mono text-slate-200">{a.host}</Td>
              <Td className="text-slate-300">{a.label}</Td>
              <Td className="mono font-medium text-slate-100">{fmtNum(a.value, 2)}</Td>
              <Td className="mono text-slate-500">{fmtNum(a.baseline_mean, 2)}</Td>
              <Td className="mono text-slate-500">{fmtNum(a.baseline_stdev, 2)}</Td>
              <Td className={Math.abs(a.z_score) >= 4 ? 'text-rose font-semibold' : Math.abs(a.z_score) >= 2.5 ? 'text-amber' : 'text-slate-400'}>
                {a.z_score > 0 ? '+' : ''}{a.z_score}
              </Td>
              <Td className={a.deviation_pct > 0 ? 'text-rose' : 'text-sky'}>{a.deviation_pct > 0 ? '+' : ''}{a.deviation_pct}%</Td>
              <Td className="mono text-[10.5px] text-slate-500">w{a.threshold.warn} / c{a.threshold.critical}</Td>
              <Td><SevBadge severity={a.severity} /></Td>
            </tr>
          ))}
        </Table>
      </Card>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHead title="Baseline model" sub="Learned distribution per metric (fleet-wide)" />
          <div className="divide-y divide-line/60">
            {Object.entries(data.baselines || {}).map(([m, v]: any) => (
              <div key={m} className="flex items-center justify-between px-5 py-2.5">
                <span className="text-[11.5px] text-slate-300">{m}</span>
                <div className="mono text-[10.5px] text-slate-500">
                  μ {fmtNum(v.mean, 2)} · σ {fmtNum(v.stdev, 2)} · n {v.samples}
                </div>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <CardHead title="Why this method" sub="Explainability note" />
          <div className="space-y-2.5 p-5 text-[11.5px] leading-relaxed text-slate-400">
            <p><b className="text-slate-200">Z-score</b> catches abrupt deviation from the learned baseline even when a static threshold has not been crossed.</p>
            <p><b className="text-slate-200">Static thresholds</b> catch slow drift that never produces a large z-score but still breaches the SLO.</p>
            <p><b className="text-slate-200">Staleness gate</b> stops the engine asserting health from old samples: a silent collector is reported as Poor, never as Excellent.</p>
            <p className="text-slate-500">A real deployment would add seasonal decomposition; this build validates the pipeline end-to-end rather than forecasting accuracy on production data.</p>
          </div>
        </Card>
      </div>
    </div>
  )
}
