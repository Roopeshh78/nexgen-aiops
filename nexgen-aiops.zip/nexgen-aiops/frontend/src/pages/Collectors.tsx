import React from 'react'
import { fmtNum, timeAgo } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, EnvTag, ErrorNote, Kpi, Loading, PageHead, Progress, StateBadge, Table, Td } from '../components/ui'

export default function Collectors() {
  const { data, error, loading } = useApi<any>('/api/collectors', [], 8000)
  if (loading) return <Loading rows={3} />
  if (error) return <ErrorNote message={error} />
  const cols = data.collectors || []
  const b = data.buffer || {}

  return (
    <div>
      <PageHead eyebrow="Collector Fleet Management" title="Local collectors inside the customer boundary"
        sub="Each collector runs the full pipeline on-premise: filter → redact → aggregate → local analysis → policy check. Raw telemetry never leaves the host."
        right={<><span className="chip mono">{cols.length} collectors</span><EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Online" value={`${cols.filter((c: any) => c.status === 'online').length}/${cols.length}`} accent="#22c55e" icon="◉" hint="heartbeat within window" />
        <Kpi label="Buffer depth" value={fmtNum(b.buffered)} unit="events" accent="#f59e0b" icon="▤" hint={`capacity ${fmtNum(b.capacity)}`} />
        <Kpi label="Duplicates suppressed" value={fmtNum(b.duplicates_suppressed)} accent="#8b5cf6" icon="⧉" hint="by unique event_id" />
        <Kpi label="Acknowledged" value={fmtNum(b.acked)} unit="events" accent="#38bdf8" icon="✓" hint="ack received from SaaS" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1.3fr_1fr]">
        <Card>
          <CardHead title="Fleet" sub="Health reflects live telemetry freshness" />
          <Table head={['Collector', 'Host', 'Region', 'Status', 'Events sent', 'Buffer', 'Freshness', 'Health']}>
            {cols.map((c: any) => (
              <tr key={c.id} className="row-hover">
                <Td>
                  <div className="font-medium text-slate-200">{c.name}</div>
                  <div className="mono text-[10px] text-slate-500">{c.id} · v{c.version}</div>
                </Td>
                <Td className="mono text-slate-400">{c.host}</Td>
                <Td className="text-slate-500">{c.region}</Td>
                <Td>
                  <span className={`chip ${c.status === 'online' ? 'border-lime/30 bg-lime/10 text-lime' : c.status === 'degraded' ? 'border-amber/30 bg-amber/10 text-amber' : 'border-rose/30 bg-rose/10 text-rose'}`}>{c.status}</span>
                </Td>
                <Td className="mono">{fmtNum(c.events_sent)}</Td>
                <Td className="mono">{c.buffer_depth}</Td>
                <Td className={c.health.stale ? 'text-amber' : 'text-slate-500'}>{c.health.stale ? `stale ${c.health.age_s}s` : timeAgo(c.last_seen)}</Td>
                <Td><StateBadge state={c.health.state} score={c.health.score} /></Td>
              </tr>
            ))}
          </Table>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHead title="Pipeline stages" sub="Executed locally, in this order" />
            <div className="space-y-1.5 p-4">
              {data.pipeline.map((p: string, i: number) => (
                <div key={p} className="flex items-center gap-2.5 rounded-lg border border-line bg-ink-900/60 px-3 py-1.5">
                  <span className="mono w-5 text-[10px] text-sky">{String(i + 1).padStart(2, '0')}</span>
                  <span className="text-[11.5px] text-slate-300">{p}</span>
                  {i >= data.pipeline.length - 2 && <span className="ml-auto text-[9px] font-bold uppercase tracking-wider text-amber">egress</span>}
                </div>
              ))}
            </div>
          </Card>
          <Card>
            <CardHead title="Reliability controls" sub="What keeps events safe when the link drops" />
            <div className="grid grid-cols-2 gap-2 p-4">
              {[
                ['Local buffering', `${fmtNum(b.buffered)} queued`],
                ['Retry attempts', fmtNum(b.attempts)],
                ['Dedupe by event_id', fmtNum(b.duplicates_suppressed)],
                ['In-flight', fmtNum(b.inflight)],
                ['Dropped (overflow)', fmtNum(b.dropped)],
                ['Stale threshold', `${data.stale_after_s}s`],
              ].map(([k, v]) => (
                <div key={k} className="rounded-lg border border-line bg-ink-900/60 px-2.5 py-2">
                  <div className="text-[9.5px] uppercase tracking-wider text-slate-600">{k}</div>
                  <div className="mt-0.5 text-[12px] font-medium text-slate-200">{v}</div>
                </div>
              ))}
            </div>
            <div className="px-4 pb-4">
              <div className="mb-1 flex items-center justify-between text-[10px] text-slate-500">
                <span>buffer utilisation</span><span>{fmtNum((b.buffered / (b.capacity || 1)) * 100, 1)}%</span>
              </div>
              <Progress value={(b.buffered / (b.capacity || 1)) * 100} color="#f59e0b" />
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
