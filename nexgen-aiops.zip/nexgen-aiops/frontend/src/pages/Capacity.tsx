import React from 'react'
import { fmtNum } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, EnvTag, ErrorNote, Kpi, Loading, PageHead, Progress, StateBadge, Table, Td } from '../components/ui'

const COL: Record<string, string> = { ok: '#22c55e', warning: '#f59e0b', critical: '#f43f5e' }

export default function Capacity() {
  const { data, error, loading } = useApi<any>('/api/capacity', [], 10000)
  if (loading) return <Loading rows={3} />
  if (error) return <ErrorNote message={error} />
  return (
    <div>
      <PageHead eyebrow="Capacity Planning" title="Headroom and time-to-exhaustion"
        sub={data.method}
        right={<><span className="chip">{data.summary.hosts} hosts</span><EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Hosts analysed" value={data.summary.hosts} accent="#38bdf8" icon="▦" hint="capacity projections" />
        <Kpi label="At risk" value={data.summary.at_risk} accent="#f43f5e" icon="⚠" hint="above 78% utilisation" />
        <Kpi label="Avg disk headroom" value={data.summary.avg_headroom_pct} unit="%" accent="#22c55e" icon="▣" hint="until 100%" />
        <Kpi label="Projection horizon" value={12} unit="steps" accent="#8b5cf6" icon="↗" hint="≈ 1 minute of live telemetry" />
      </div>

      <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {data.hosts.map((h: any) => (
          <Card key={h.host} className="card-pad">
            <div className="flex items-start justify-between">
              <div>
                <div className="mono text-[12px] font-medium text-slate-200">{h.host}</div>
                <div className="text-[10.5px] text-slate-500">{h.collector} · {h.region}</div>
              </div>
              <StateBadge state={h.state} />
            </div>
            <div className="mt-3 space-y-2.5">
              {[['cpu_pct', 'CPU', '#38bdf8'], ['mem_pct', 'Memory', '#8b5cf6'], ['disk_pct', 'Disk', '#f59e0b']].map(([k, label, color]) => (
                <div key={k}>
                  <div className="mb-1 flex items-center justify-between text-[10.5px]">
                    <span className="text-slate-400">{label}</span>
                    <span className="text-slate-300">{fmtNum(h[k]?.current, 1)}% <span className="text-slate-600">· {fmtNum(h[k]?.headroom_pct, 1)}% free</span></span>
                  </div>
                  <Progress value={h[k]?.current || 0} color={h[k]?.current > 90 ? '#f43f5e' : h[k]?.current > 78 ? '#f59e0b' : color as string} />
                  <div className="mt-0.5 flex justify-between text-[9.5px] text-slate-600">
                    <span>{h[k]?.trend || '—'}</span>
                    <span>{h[k]?.steps_to_full ? `full in +${h[k].steps_to_full}` : 'no breach in horizon'}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-3 rounded-lg border px-2.5 py-1.5 text-[10.5px]"
              style={{ borderColor: `${COL[h.risk]}40`, background: `${COL[h.risk]}10`, color: COL[h.risk] }}>
              risk: {h.risk}
            </div>
          </Card>
        ))}
      </div>

      <Card className="mt-4">
        <CardHead title="Exhaustion forecast" sub="Steps until each dimension reaches 100%" />
        <Table head={['Host', 'CPU now', 'CPU full', 'Mem now', 'Mem full', 'Disk now', 'Disk full', 'Risk']}>
          {data.hosts.map((h: any) => (
            <tr key={h.host} className="row-hover">
              <Td className="mono text-slate-200">{h.host}</Td>
              <Td className="mono">{fmtNum(h.cpu_pct?.current, 1)}%</Td>
              <Td className="mono text-slate-500">{h.cpu_pct?.steps_to_full ? `+${h.cpu_pct.steps_to_full}` : '—'}</Td>
              <Td className="mono">{fmtNum(h.mem_pct?.current, 1)}%</Td>
              <Td className="mono text-slate-500">{h.mem_pct?.steps_to_full ? `+${h.mem_pct.steps_to_full}` : '—'}</Td>
              <Td className="mono">{fmtNum(h.disk_pct?.current, 1)}%</Td>
              <Td className="mono text-slate-500">{h.disk_pct?.steps_to_full ? `+${h.disk_pct.steps_to_full}` : '—'}</Td>
              <Td><span style={{ color: COL[h.risk] }} className="text-[11px] font-semibold">{h.risk}</span></Td>
            </tr>
          ))}
        </Table>
      </Card>
    </div>
  )
}
