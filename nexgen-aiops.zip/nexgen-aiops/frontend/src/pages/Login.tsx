import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { api, post, setSession } from '../api'

const ACCOUNTS = [
  { email: 'admin@acme.io', role: 'Platform admin', tenant: 'Acme Financial' },
  { email: 'analyst@acme.io', role: 'Analyst', tenant: 'Acme Financial' },
  { email: 'soc@acme.io', role: 'Security analyst', tenant: 'Acme Financial' },
  { email: 'ops@northwind.io', role: 'Analyst', tenant: 'Northwind Logistics' },
  { email: 'sre@orbit.io', role: 'Analyst', tenant: 'Orbit Media Labs' },
]

export default function Login() {
  const nav = useNavigate()
  const [email, setEmail] = useState('admin@acme.io')
  const [password, setPassword] = useState('NexGen#2026')
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const [accounts, setAccounts] = useState(ACCOUNTS)

  useEffect(() => {
    api<any>('/api/auth/demo-accounts')
      .then(r => { if (Array.isArray(r) && r.length) setAccounts(r.map((a: any) => ({ email: a.email, role: a.role.replace('_', ' '), tenant: a.tenant_id }))) })
      .catch(() => { /* fall back to static list */ })
  }, [])

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setBusy(true); setErr('')
    try {
      const r = await post<any>('/api/auth/login', { email, password })
      setSession(r.token, r.user)
      nav('/')
    } catch (e: any) {
      setErr(e.message || 'Login failed')
    } finally { setBusy(false) }
  }

  return (
    <div className="relative grid min-h-screen lg:grid-cols-[1.15fr_1fr]">
      <div className="relative hidden flex-col justify-between overflow-hidden border-r border-line p-10 lg:flex grid-bg">
        <div className="relative z-10">
          <div className="flex items-center gap-3">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-sky to-violet text-[16px] font-bold text-ink-950">N</div>
            <div>
              <div className="text-[14px] font-semibold tracking-[0.16em] text-white">NEXGEN</div>
              <div className="text-[9.5px] tracking-[0.3em] text-slate-500">AIOPS</div>
            </div>
          </div>
          <h1 className="mt-16 max-w-lg text-[34px] font-semibold leading-[1.15] tracking-tight text-white">
            AIOps intelligence that never sees your raw data.
          </h1>
          <p className="mt-4 max-w-md text-[13px] leading-relaxed text-slate-400">
            Telemetry is filtered, redacted, aggregated and allow-listed inside your own environment.
            Only approved metadata crosses the boundary — and every byte that leaves is provable.
          </p>
          <div className="mt-10 grid max-w-md gap-2.5">
            {[
              ['Local pipeline', 'Filter → Redact → Aggregate → Local analysis → Policy check'],
              ['Allow-list egress', 'Payload built field-by-field; unknown fields cannot be constructed'],
              ['Explainable AIOps', 'Every alert: what, why, contributing signals, next action'],
            ].map(([t, d]) => (
              <div key={t} className="rounded-xl border border-line bg-ink-800/60 px-4 py-3">
                <div className="text-[11.5px] font-semibold text-slate-200">{t}</div>
                <div className="mt-0.5 text-[10.5px] leading-relaxed text-slate-500">{d}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="relative z-10 flex items-center gap-3 text-[10px] text-slate-600">
          <span className="chip">two-tier architecture</span>
          <span className="chip">four health states</span>
          <span className="chip">UTC everywhere</span>
        </div>
        <div className="pointer-events-none absolute -bottom-40 -left-24 h-[420px] w-[420px] rounded-full bg-sky/10 blur-3xl" />
        <div className="pointer-events-none absolute -right-24 top-10 h-[360px] w-[360px] rounded-full bg-violet/10 blur-3xl" />
      </div>

      <div className="flex items-center justify-center p-6">
        <div className="w-full max-w-[400px] animate-fade-up">
          <div className="lg:hidden mb-6 flex items-center gap-2.5">
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-sky to-violet text-[14px] font-bold text-ink-950">N</div>
            <span className="text-[13px] font-semibold tracking-[0.16em] text-white">NEXGEN AIOPS</span>
          </div>
          <div className="label">Secure access</div>
          <h2 className="mt-1 text-[22px] font-semibold text-white">Sign in to the control plane</h2>
          <p className="mt-1 text-[12px] text-slate-500">Tenant-scoped JWT session. All access is written to the hash-linked audit chain.</p>

          <form onSubmit={submit} className="mt-6 space-y-3">
            <div>
              <label className="label">Work email</label>
              <input className="input mt-1.5" value={email} onChange={e => setEmail(e.target.value)} autoComplete="username" />
            </div>
            <div>
              <label className="label">Password</label>
              <input className="input mt-1.5" type="password" value={password} onChange={e => setPassword(e.target.value)} autoComplete="current-password" />
            </div>
            {err && <div className="rounded-lg border border-rose/30 bg-rose/10 px-3 py-2 text-[11.5px] text-rose">{err}</div>}
            <button className="btn btn-primary w-full py-2.5" disabled={busy}>
              {busy ? 'Authenticating…' : 'Sign in'}
            </button>
          </form>

          <div className="mt-6">
            <div className="label">Demo accounts · password NexGen#2026</div>
            <div className="mt-2 space-y-1">
              {accounts.map((a: any) => (
                <button key={a.email} onClick={() => { setEmail(a.email); setPassword('NexGen#2026') }}
                  className="flex w-full items-center justify-between rounded-lg border border-line bg-ink-800/60 px-3 py-2 text-left transition-colors hover:border-sky/30">
                  <span className="mono text-slate-300">{a.email}</span>
                  <span className="text-[10px] uppercase tracking-wider text-slate-500">{a.role}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
