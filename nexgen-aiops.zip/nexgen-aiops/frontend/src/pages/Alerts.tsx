import React, { useState } from 'react'
import { api, post, timeAgo } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, Empty, EnvTag, ErrorNote, Json, Loading, PageHead, SevBadge, Table, Td } from '../components/ui'

export default function Alerts() {
  const [filter, setFilter] = useState<'all' | 'open' | 'acknowledged' | 'resolved'>('open')
  const [expanded, setExpanded] = useState<string | null>(null)
  const { data, error, loading, reload } = useApi<any>(`/api/alerts${filter === 'all' ? '' : `?state=${filter}`}`, [filter], 8000)
  const [busy, setBusy] = useState('')

  const act = async (id: string, kind: 'ack' | 'resolve') => {
    setBusy(id)
    try { await post(`/api/alerts/${id}/${kind}`); await reload() } catch { /* reload shows state */ }
    setBusy('')
  }

  if (loading) return <Loading rows={3} />
  if (error) return <ErrorNote message={error} />
  const alerts = data.alerts || []

  return (
    <div>
      <PageHead eyebrow="Alert Management" title="Deduplicated, explained, actioned"
        sub="Each alert carries a fingerprint (metric::collector) so repeats increment occurrences instead of creating new noise. Open any row to read the explainability trace."
        right={<><span className="chip border-mint/30 bg-mint/10 text-mint">{data.counts.open} open</span><EnvTag /></>} />

      <div className="mb-4 flex flex-wrap items-center gap-2">
        {(['open', 'acknowledged', 'resolved', 'all'] as const).map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`btn btn-xs capitalize ${filter === f ? 'btn-primary' : ''}`}>
            {f} {f !== 'all' && <span className="opacity-60">{data.counts[f] ?? ''}</span>}
          </button>
        ))}
        <button className="btn btn-xs ml-auto" onClick={reload}>↻ refresh</button>
      </div>

      <Card>
        <CardHead title={`${filter} alerts`} sub={`${alerts.length} rows · click to inspect explanation`} />
        {alerts.length === 0 ? <Empty text="Nothing in this state. Trigger a scenario from the Live demo drawer." /> : (
          <Table head={['Severity', 'Alert', 'Host', 'Occurrences', 'Suppressed', 'State', 'Last seen', 'Actions']}>
            {alerts.map((a: any) => (
              <React.Fragment key={a.id}>
                <tr className="row-hover cursor-pointer" onClick={() => setExpanded(expanded === a.id ? null : a.id)}>
                  <Td><SevBadge severity={a.severity} /></Td>
                  <Td className="max-w-[280px] truncate font-medium text-slate-200">{a.title}</Td>
                  <Td className="mono text-slate-400">{a.host}</Td>
                  <Td className="mono">{a.occurrences}</Td>
                  <Td className="mono text-violet">{a.suppressed}</Td>
                  <Td><span className="chip">{a.state}</span></Td>
                  <Td className="text-slate-500">{timeAgo(a.last_seen)}</Td>
                  <Td>
                    <div className="flex gap-1">
                      <button className="btn btn-xs" disabled={busy === a.id || a.state !== 'open'}
                        onClick={e => { e.stopPropagation(); act(a.id, 'ack') }}>ack</button>
                      <button className="btn btn-xs" disabled={busy === a.id || a.state === 'resolved'}
                        onClick={e => { e.stopPropagation(); act(a.id, 'resolve') }}>resolve</button>
                    </div>
                  </Td>
                </tr>
                {expanded === a.id && (
                  <tr>
                    <td colSpan={8} className="border-b border-line bg-ink-950/70 px-5 py-4">
                      <div className="grid gap-4 lg:grid-cols-[1.2fr_1fr]">
                        <div>
                          <div className="label mb-1">What happened</div>
                          <p className="text-[11.5px] leading-relaxed text-slate-300">{a.explanation?.what_happened}</p>
                          <div className="label mb-1 mt-3">Why it was detected</div>
                          <p className="text-[11.5px] leading-relaxed text-slate-400">{a.explanation?.why_detected}</p>
                          <div className="label mb-1 mt-3">Recommended action</div>
                          <p className="rounded-lg border border-sky/25 bg-sky/5 px-3 py-2 text-[11.5px] leading-relaxed text-sky">{a.explanation?.recommended_action}</p>
                        </div>
                        <div>
                          <div className="label mb-1">Contributing signals</div>
                          <div className="space-y-1">
                            {(a.explanation?.contributing_signals || []).map((s: any, i: number) => (
                              <div key={i} className="flex items-center justify-between rounded-md border border-line bg-ink-900/70 px-2.5 py-1.5">
                                <span className="text-[11px] text-slate-300">{s.name}</span>
                                <span className="mono text-[10.5px] text-slate-400">{String(s.value)} · w{s.weight}</span>
                              </div>
                            ))}
                          </div>
                          <div className="mt-2 flex flex-wrap gap-1.5">
                            <span className="chip">fingerprint {a.fingerprint}</span>
                            <span className="chip">confidence {a.explanation?.confidence}</span>
                            {a.incident_id && <span className="chip">incident {a.incident_id}</span>}
                          </div>
                        </div>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
          </Table>
        )}
      </Card>
    </div>
  )
}
