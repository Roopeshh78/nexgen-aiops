import React from 'react'
import { fmtNum } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, EnvTag, ErrorNote, Kpi, Loading, PageHead, Progress, StateBadge,
  Table, Td, TrendChart } from '../components/ui'

const ACC: Record<string, string> = { Excellent: '#22c55e', Good: '#38bdf8', Fair: '#f59e0b', Poor: '#f43f5e' }

export default function Cloud() {
  const { data, error, loading } = useApi<any>('/api/cloud', [], 8000)
  if (loading) return <Loading rows={4} />
  if (error) return <ErrorNote message={error} />
  return (
    <div>
      <PageHead eyebrow="Cloud Observability" title="Regional posture and workload restarts"
        sub="Per-region collector health, workload inventory and pod restart signals. Cloud provider APIs are not called in this build — the data source is the internal telemetry stream."
        right={<><span className="chip mono">{data.regions.length} regions</span><EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Regions monitored" value={data.regions.length} accent="#38bdf8" icon="☁" hint="collector footprint" />
        <Kpi label="Workloads" value={data.workloads.length} accent="#8b5cf6" icon="⬡" hint="namespaced services" />
        <Kpi label="Pod restarts" value={fmtNum(data.pod_restarts?.length ? data.pod_restarts[data.pod_restarts.length - 1].v : 0, 0)}
          accent="#f59e0b" trend={data.pod_restarts} hint="rolling count" />
        <Kpi label="Degraded workloads" value={data.workloads.filter((w: any) => w.state !== 'Excellent').length}
          accent="#f43f5e" icon="⚠" hint="outside the Excellent band" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_1.3fr]">
        <Card>
          <CardHead title="Regional health" sub="Minimum collector score inside each region" />
          <div className="divide-y divide-line/60">
            {data.regions.map((r: any) => (
              <div key={r.region} className="px-5 py-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="mono text-[12px] font-medium text-slate-200">{r.region}</div>
                    <div className="text-[10.5px] text-slate-500">{r.collectors} collectors · {r.nodes} workloads</div>
                  </div>
                  <StateBadge state={r.state} score={Math.round(r.score)} />
                </div>
                <div className="mt-2"><Progress value={r.score} color={ACC[r.state]} /></div>
              </div>
            ))}
          </div>
        </Card>
        <Card><CardHead title="Pod restart trend" sub="Restart spikes correlate with node pressure" />
          <div className="card-pad"><TrendChart data={data.pod_restarts} color="#f59e0b" label="Restarts" /></div>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHead title="Workload inventory" sub="Namespace prod · derived from collector service metadata" />
        <Table head={['Workload', 'Namespace', 'Collector', 'Restarts', 'State']}>
          {data.workloads.map((w: any, i: number) => (
            <tr key={i} className="row-hover">
              <Td className="font-medium text-slate-200">{w.name}</Td>
              <Td className="text-slate-500">{w.namespace}</Td>
              <Td className="text-slate-400">{w.collector}</Td>
              <Td className={w.restarts > 2 ? 'text-amber' : 'text-slate-400'}>{w.restarts}</Td>
              <Td><StateBadge state={w.state} /></Td>
            </tr>
          ))}
        </Table>
      </Card>
    </div>
  )
}
