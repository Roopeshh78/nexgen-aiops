import React from 'react'
import { fmtNum } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, EnvTag, ErrorNote, Kpi, Loading, MultiChart, PageHead, Progress,
  StateBadge, Table, Td, TrendChart } from '../components/ui'

const ACC: Record<string, string> = { Excellent: '#22c55e', Good: '#38bdf8', Fair: '#f59e0b', Poor: '#f43f5e' }

export default function Application() {
  const { data, error, loading } = useApi<any>('/api/app', [], 8000)
  if (loading) return <Loading rows={4} />
  if (error) return <ErrorNote message={error} />
  const s = data.series || {}
  const last = (a: any[]) => (a?.length ? a[a.length - 1].v : 0)
  const failing = data.services.filter((x: any) => x.health === 'Fair' || x.health === 'Poor')

  return (
    <div>
      <PageHead eyebrow="Application Observability" title="Service health, tail latency and error budgets"
        sub="API response time, request volume, error rate, availability and distributed service health — instrumented at the edge, analysed locally."
        right={<><span className="chip mono">{data.services.length} services</span><EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="API p95" value={fmtNum(last(s.api_p95_ms), 0)} unit="ms" accent="#38bdf8" trend={s.api_p95_ms} hint="95th percentile" />
        <Kpi label="Request volume" value={fmtNum(last(s.throughput_rps), 0)} unit="req/s" accent="#8b5cf6" trend={s.throughput_rps} hint="edge ingress" />
        <Kpi label="Error rate" value={fmtNum(last(s.error_rate_pct), 2)} unit="%" accent="#f43f5e" trend={s.error_rate_pct} hint="5xx / total" />
        <Kpi label="Availability" value={fmtNum(last(s.svc_availability_pct), 3)} unit="%" accent="#22c55e" trend={s.svc_availability_pct} hint="health-check pass" />
      </div>

      {failing.length > 0 && (
        <div className="mt-4 rounded-xl border border-amber/30 bg-amber/10 px-4 py-2.5 text-[11.5px] text-amber">
          {failing.length} service(s) below the Excellent band: {failing.map((f: any) => f.name).join(', ')}. Tail latency and error rate are the dominant signals.
        </div>
      )}

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card><CardHead title="Tail latency vs error rate" sub="Both must move together to indicate a real incident" />
          <div className="card-pad"><MultiChart series={[
            { name: 'p95 ms', color: '#38bdf8', data: s.api_p95_ms },
            { name: 'Error %', color: '#f43f5e', data: s.error_rate_pct },
          ]} height={240} /></div></Card>
        <Card><CardHead title="Availability" sub="Service objective 99.5%" />
          <div className="card-pad"><TrendChart data={s.svc_availability_pct} color="#22c55e" label="Availability" unit="%" /></div></Card>
      </div>

      <Card className="mt-4">
        <CardHead title="Service inventory" sub="Health score blends p95, error rate and availability" />
        <Table head={['Service', 'Collector', 'Region', 'p95', 'Error rate', 'Availability', 'Throughput', 'Score', 'State']}>
          {data.services.map((sv: any) => (
            <tr key={`${sv.collector}-${sv.name}`} className="row-hover">
              <Td className="font-medium text-slate-200">{sv.name}</Td>
              <Td className="text-slate-400">{sv.collector}</Td>
              <Td className="text-slate-500">{sv.region}</Td>
              <Td className="mono">{fmtNum(sv.p95_ms, 0)} ms</Td>
              <Td className={sv.error_rate_pct > 4 ? 'text-rose' : sv.error_rate_pct > 1.5 ? 'text-amber' : 'text-slate-300'}>{fmtNum(sv.error_rate_pct, 2)}%</Td>
              <Td className="text-slate-300">{fmtNum(sv.availability_pct, 3)}%</Td>
              <Td className="text-slate-400">{fmtNum(sv.throughput_rps, 0)}</Td>
              <Td>
                <div className="flex items-center gap-2">
                  <span className="w-7 text-[11px] text-slate-200">{sv.score}</span>
                  <div className="w-14"><Progress value={sv.score} color={ACC[sv.health]} /></div>
                </div>
              </Td>
              <Td><StateBadge state={sv.health} /></Td>
            </tr>
          ))}
        </Table>
      </Card>
    </div>
  )
}
