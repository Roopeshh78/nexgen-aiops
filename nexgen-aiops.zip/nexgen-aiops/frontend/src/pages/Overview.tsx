import React from 'react'
import { Link } from 'react-router-dom'
import { api, clock, fmtNum, timeAgo } from '../api'
import { useApi, useLive } from '../hooks'
import {
  Card, CardHead, EnvTag, Kpi, Loading, MultiChart, PageHead, Progress,
  SevBadge, StateBadge, Table, Td, TrendChart, ErrorNote,
} from '../components/ui'

const STATE_ACCENT: Record<string, string> = { Excellent: '#22c55e', Good: '#38bdf8', Fair: '#f59e0b', Poor: '#f43f5e' }

export default function Overview() {
  const { data, error, loading } = useApi<any>('/api/overview', [], 8000)
  const { tick } = useLive()
  if (loading) return <Loading rows={4} />
  if (error) return <ErrorNote message={error} />
  if (!data) return null
  const k = data.kpis
  const accent = STATE_ACCENT[data.overall.state] || '#38bdf8'
  const cpuSeries = tick?.cpu?.length ? tick.cpu : data.series?.cpu_pct
  const latSeries = tick?.latency?.length ? tick.latency : data.series?.latency_ms

  return (
    <div>
      <PageHead
        eyebrow="Executive Overview"
        title={`${data.tenant.name} — fleet posture`}
        sub="Single pane across infrastructure, network, application, security and cloud telemetry. Health is derived from live metadata only; stale telemetry is never rendered as healthy."
        right={<>
          <span className="chip">{data.tenant.region}</span>
          <span className="chip">{data.tenant.plan}</span>
          <span className="chip mono">tick {data.tick_count}</span>
          <EnvTag />
        </>}
      />

      <div className="grid gap-4 lg:grid-cols-[1.35fr_1fr]">
        <Card className="card-pad relative overflow-hidden">
          <div className="pointer-events-none absolute -right-16 -top-16 h-56 w-56 rounded-full blur-3xl" style={{ background: `${accent}18` }} />
          <div className="flex items-start justify-between">
            <div>
              <div className="label">Composite health</div>
              <div className="mt-2 flex items-end gap-3">
                <span className="text-[46px] font-semibold leading-none tracking-tight" style={{ color: accent }}>{data.overall.score}</span>
                <div className="mb-1.5">
                  <StateBadge state={data.overall.state} />
                  <div className="mt-1 text-[10.5px] text-slate-500">weighted across {k.collectors_total} collectors</div>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="label">Worst state observed</div>
              <div className="mt-1.5"><StateBadge state={data.overall.worst_collector_state} /></div>
              {data.overall.stale_collectors > 0 && (
                <div className="mt-2 rounded-md border border-amber/30 bg-amber/10 px-2 py-1 text-[10px] text-amber">
                  {data.overall.stale_collectors} collector(s) stale → forced to Poor
                </div>
              )}
            </div>
          </div>
          <div className="mt-5 grid grid-cols-2 gap-2.5 sm:grid-cols-4">
            {[['Excellent', '#22c55e'], ['Good', '#38bdf8'], ['Fair', '#f59e0b'], ['Poor', '#f43f5e']].map(([label, color]) => {
              const n = data.health_states.filter((h: any) => h.state === label).length
              return (
                <div key={label} className="rounded-lg border border-line bg-ink-900/60 px-2.5 py-2">
                  <div className="flex items-center gap-1.5">
                    <span className="h-1.5 w-1.5 rounded-full" style={{ background: color }} />
                    <span className="text-[10px] uppercase tracking-wider text-slate-500">{label}</span>
                  </div>
                  <div className="mt-1 text-[17px] font-semibold text-white">{n}</div>
                </div>
              )
            })}
          </div>
        </Card>

        <Card>
          <CardHead title="Signal stream" sub="Live WebSocket feed from the ingestion tier" right={
            <span className="chip border-mint/30 bg-mint/10 text-mint">{tick ? 'connected' : 'waiting'}</span>
          } />
          <div className="grid grid-cols-2 gap-px bg-line/60">
            {[
              ['CTC open alerts', tick?.open_alerts ?? k.open_alerts],
              ['Critical', tick?.critical ?? k.critical_alerts],
              ['Incidents', tick?.incidents ?? k.active_incidents],
              ['Samples ingested', fmtNum(tick?.samples ?? k.telemetry_events)],
            ].map(([label, val]) => (
              <div key={label as string} className="bg-ink-800/80 px-4 py-3">
                <div className="label">{label}</div>
                <div className="mt-1 text-[19px] font-semibold text-white">{val as any}</div>
              </div>
            ))}
          </div>
          <div className="px-4 py-3">
            <div className="flex items-center justify-between text-[10.5px] text-slate-500">
              <span>UTC {clock(tick?.utc)}</span>
              <span>tick interval 5s</span>
            </div>
            <div className="mt-2 flex flex-wrap gap-1.5">
              {(tick?.scenarios || data.scenarios || []).map((s: string) => (
                <span key={s} className="chip border-sky/25 bg-sky/10 text-sky">{s.replace(/_/g, ' ')}</span>
              ))}
            </div>
          </div>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Collectors online" value={`${k.collectors_online}/${k.collectors_total}`} hint="local collector fleet"
          accent="#22c55e" icon="◉" />
        <Kpi label="Alert noise reduction" value={k.noise_reduction_pct} unit="%" hint={`${fmtNum(k.alerts_suppressed)} duplicate signals suppressed`}
          accent="#8b5cf6" icon="✦" />
        <Kpi label="Approved egress" value={k.egress_batches} unit="batches" hint={`${k.egress_kb} KB metadata left the boundary`}
          accent="#38bdf8" icon="⇱" />
        <Kpi label="Ingest latency" value={k.ingest_latency_ms} unit="ms" hint="collector → metadata store" accent="#2dd4bf" icon="⚡" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHead title="Compute pressure" sub="CPU vs memory utilisation, fleet average" right={<Link className="link text-[11px]" to="/infrastructure">Infrastructure →</Link>} />
          <div className="card-pad">
            <MultiChart unit="%" series={[
              { name: 'CPU %', color: '#38bdf8', data: cpuSeries },
              { name: 'Memory %', color: '#8b5cf6', data: data.series?.mem_pct },
            ]} height={218} />
          </div>
        </Card>
        <Card>
          <CardHead title="Service latency & error budget" sub="Network RTT against application error rate" right={<Link className="link text-[11px]" to="/application">Application →</Link>} />
          <div className="card-pad">
            <MultiChart unit="" series={[
              { name: 'RTT ms', color: '#2dd4bf', data: latSeries },
              { name: 'Error %', color: '#f43f5e', data: data.series?.error_rate_pct },
            ]} height={218} />
          </div>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-[1.1fr_1fr]">
        <Card>
          <CardHead title="Collector health matrix" sub="Four-state model · staleness forces Poor" right={<Link className="link text-[11px]" to="/collectors">Fleet →</Link>} />
          <Table head={['Collector', 'Host', 'Region', 'Score', 'State', 'Freshness']}>
            {data.health_states.map((h: any) => (
              <tr key={h.collector} className="row-hover">
                <Td className="font-medium text-slate-200">{h.collector}</Td>
                <Td className="mono text-slate-400">{h.host}</Td>
                <Td className="text-slate-500">{data.tenant.region}</Td>
                <Td>
                  <div className="flex items-center gap-2">
                    <span className="w-8 text-[11px] font-semibold text-slate-200">{h.score}</span>
                    <div className="w-16"><Progress value={h.score} color={STATE_ACCENT[h.state]} /></div>
                  </div>
                </Td>
                <Td><StateBadge state={h.state} /></Td>
                <Td className={h.stale ? 'text-amber' : 'text-slate-500'}>{h.stale ? `stale ${h.age_s}s` : `${h.age_s}s ago`}</Td>
              </tr>
            ))}
          </Table>
        </Card>

        <Card>
          <CardHead title="Highest-priority alerts" sub="Deduplicated and correlated before reaching a human" right={<Link className="link text-[11px]" to="/alerts">All alerts →</Link>} />
          <div className="divide-y divide-line/60">
            {data.top_alerts.length === 0 && (
              <div className="px-5 py-10 text-center text-[12px] text-slate-500">No open alerts. Fleet is within baselines.</div>
            )}
            {data.top_alerts.map((a: any) => (
              <Link key={a.id} to="/alerts" className="block px-5 py-3 transition-colors hover:bg-white/[0.025]">
                <div className="flex items-center justify-between gap-3">
                  <span className="truncate text-[12px] font-medium text-slate-200">{a.title}</span>
                  <SevBadge severity={a.severity} />
                </div>
                <div className="mt-1 flex items-center gap-2 text-[10.5px] text-slate-500">
                  <span className="mono">{a.host}</span>
                  <span>·</span>
                  <span>{a.occurrences} occurrences</span>
                  <span>·</span>
                  <span>{timeAgo(a.last_seen)}</span>
                  <span className="ml-auto chip">{a.state}</span>
                </div>
              </Link>
            ))}
          </div>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          ['Privacy', 'Allow-listed metadata egress', '/privacy', '⧉'],
          ['Egress proof', 'Show the exact JSON that left', '/egress', '⇱'],
          ['AIOps centre', '10 modules, one engine', '/aiops', '✦'],
          ['Audit chain', 'Hash-linked, verifiable', '/audit', '⛓'],
        ].map(([t, d, to, icon]) => (
          <Link key={t} to={to} className="card card-pad group transition-colors hover:border-sky/35">
            <div className="flex items-center justify-between">
              <span className="text-[13px] font-semibold text-slate-200">{t}</span>
              <span className="text-[13px] text-slate-600 group-hover:text-sky">{icon}</span>
            </div>
            <div className="mt-1 text-[11px] text-slate-500">{d}</div>
          </Link>
        ))}
      </div>
    </div>
  )
}
