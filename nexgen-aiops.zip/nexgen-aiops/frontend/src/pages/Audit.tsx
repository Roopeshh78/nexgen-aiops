import React, { useState } from 'react'
import { useApi } from '../hooks'
import { Card, CardHead, Empty, EnvTag, ErrorNote, Json, Kpi, Loading, PageHead, Table, Td } from '../components/ui'

export default function Audit() {
  const { data, error, loading, reload } = useApi<any>('/api/audit', [], 12000)
  const [open, setOpen] = useState<number | null>(null)
  if (loading) return <Loading rows={3} />
  if (error) return <ErrorNote message={error} />
  const logs = data.logs || []
  const chain = data.chain || {}

  return (
    <div>
      <PageHead eyebrow="Audit Logs" title="Hash-linked, tamper-evident trail"
        sub="Each entry stores the previous hash and its own SHA-256 over actor, action, resource and detail. Verification walks the chain and reports the first break."
        right={<button className="btn" onClick={reload}>↻ verify chain</button>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Entries" value={chain.checked ?? logs.length} accent="#38bdf8" icon="⛓" hint="in this tenant" />
        <Kpi label="Chain integrity" value={chain.valid ? 'VALID' : 'BROKEN'} accent={chain.valid ? '#22c55e' : '#f43f5e'} icon={chain.valid ? '✓' : '⚠'}
          hint={chain.valid ? 'every hash recomputed' : `break at entry ${chain.broken_at}`} />
        <Kpi label="Distinct actors" value={new Set(logs.map((l: any) => l.actor)).size} accent="#8b5cf6" icon="◉" hint="in the recent window" />
        <Kpi label="Head hash" value={String(chain.head || '—').slice(0, 8)} accent="#2dd4bf" icon="⌗" hint="current chain head" />
      </div>

      <Card className="mt-4">
        <CardHead title="Audit entries" sub="Newest first · click a row for the detail payload" />
        {logs.length === 0 ? <Empty text="No audit entries for this tenant yet." /> : (
          <Table head={['ID', 'Actor', 'Action', 'Resource', 'Prev hash', 'Hash', 'When']}>
            {logs.map((l: any) => (
              <React.Fragment key={l.id}>
                <tr className="row-hover cursor-pointer" onClick={() => setOpen(open === l.id ? null : l.id)}>
                  <Td className="mono text-slate-500">#{l.id}</Td>
                  <Td className="text-slate-200">{l.actor}</Td>
                  <Td className="mono text-[11px] text-sky">{l.action}</Td>
                  <Td className="mono text-[11px] text-slate-500">{l.resource || '—'}</Td>
                  <Td className="mono text-[10px] text-slate-600">{l.prev_hash?.slice(0, 12)}</Td>
                  <Td className="mono text-[10px] text-slate-400">{l.hash?.slice(0, 12)}</Td>
                  <Td className="mono text-[10.5px] text-slate-500">{l.ts?.slice(11, 19)}Z</Td>
                </tr>
                {open === l.id && (
                  <tr><td colSpan={7} className="border-b border-line bg-ink-950/70 px-5 py-3">
                    <Json value={{ id: l.id, actor: l.actor, action: l.action, resource: l.resource, detail: l.detail, prev_hash: l.prev_hash, hash: l.hash }} max={20} />
                  </td></tr>
                )}
              </React.Fragment>
            ))}
          </Table>
        )}
      </Card>
    </div>
  )
}
