import React, { useState } from 'react'
import { post, timeAgo } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, EnvTag, ErrorNote, Kpi, Loading, PageHead, Table, Td } from '../components/ui'

export default function Tenants() {
  const { data, error, loading, reload } = useApi<any>('/api/tenants', [], 15000)
  const [name, setName] = useState('')
  const [plan, setPlan] = useState('Business')
  const [msg, setMsg] = useState('')
  const [busy, setBusy] = useState(false)

  const create = async () => {
    if (!name.trim()) { setMsg('Name required'); return }
    setBusy(true); setMsg('')
    try {
      const r = await post<any>('/api/tenants', { name, plan })
      setMsg(`Tenant created: ${r.id}`); setName(''); await reload()
    } catch (e: any) { setMsg(e.message) }
    setBusy(false)
  }

  if (loading) return <Loading rows={3} />
  if (error) return <ErrorNote message={error} />
  const ts = data.tenants || []

  return (
    <div>
      <PageHead eyebrow="Tenant Management" title={data.scoped ? 'Your tenant' : 'Tenant isolation'}
        sub="Every query is scoped by the JWT tenant claim. A non-admin caller asking for another tenant receives 403 — enforced server-side, not hidden in the UI."
        right={<><span className="chip mono">{ts.length} tenant(s)</span><EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Tenants visible" value={ts.length} accent="#38bdf8" icon="⛁" hint={data.scoped ? 'scoped to your claim' : 'platform admin view'} />
        <Kpi label="Users" value={ts.reduce((a: number, t: any) => a + (t.users || 0), 0)} accent="#8b5cf6" icon="◉" hint="across visible tenants" />
        <Kpi label="Collectors" value={ts.reduce((a: number, t: any) => a + (t.collectors || 0), 0)} accent="#2dd4bf" icon="▤" hint="registered fleet" />
        <Kpi label="Open alerts" value={ts.reduce((a: number, t: any) => a + (t.alerts || 0), 0)} accent="#f43f5e" icon="⚠" hint="visible scope" />
      </div>

      <Card className="mt-4">
        <CardHead title="Tenants" sub="Plan, region and egress quota per isolation boundary" />
        <Table head={['Tenant', 'ID', 'Plan', 'Region', 'Users', 'Collectors', 'Open alerts', 'Quota', 'Status']}>
          {ts.map((t: any) => (
            <tr key={t.id} className="row-hover">
              <Td className="font-medium text-slate-200">{t.name}</Td>
              <Td className="mono text-slate-500">{t.id}</Td>
              <Td className="text-slate-300">{t.plan}</Td>
              <Td className="text-slate-400">{t.region}</Td>
              <Td className="mono">{t.users}</Td>
              <Td className="mono">{t.collectors}</Td>
              <Td className={`mono ${t.alerts > 0 ? 'text-amber' : 'text-slate-500'}`}>{t.alerts ?? '—'}</Td>
              <Td className="mono text-slate-400">{t.quota} MB/day</Td>
              <Td><span className="chip border-lime/25 bg-lime/10 text-lime">{t.status || 'active'}</span></Td>
            </tr>
          ))}
        </Table>
      </Card>

      {!data.scoped && (
        <Card className="mt-4">
          <CardHead title="Create tenant" sub="Platform admin only — validated server-side" />
          <div className="flex flex-wrap items-end gap-2 p-4">
            <div className="min-w-[220px] flex-1">
              <label className="label">Tenant name</label>
              <input className="input mt-1" value={name} onChange={e => setName(e.target.value)} placeholder="Kepler Retail Group" />
            </div>
            <div>
              <label className="label">Plan</label>
              <select className="input mt-1 w-auto" value={plan} onChange={e => setPlan(e.target.value)}>
                {['Growth', 'Business', 'Enterprise'].map(p => <option key={p}>{p}</option>)}
              </select>
            </div>
            <button className="btn btn-primary" onClick={create} disabled={busy}>{busy ? 'Creating…' : 'Create'}</button>
            {msg && <span className="text-[11px] text-slate-400">{msg}</span>}
          </div>
        </Card>
      )}

      <div className="mt-4 rounded-xl border border-line bg-ink-800/60 p-4 text-[11.5px] leading-relaxed text-slate-400">
        <b className="text-slate-200">Isolation model.</b> JWT carries <span className="mono text-sky">tenant_id</span>; the API derives scope from the token, never from a client-supplied header.
        Requesting another tenant's data as a non-admin returns <span className="mono text-rose">403 Cross-tenant access denied</span>. Opening a single alert also re-checks ownership.
      </div>
    </div>
  )
}
