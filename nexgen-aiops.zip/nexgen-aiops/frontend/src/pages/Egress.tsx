import React, { useState } from 'react'
import { fmtBytes, post, timeAgo } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, Empty, EnvTag, ErrorNote, Json, Kpi, Loading, PageHead, Table, Td } from '../components/ui'

export default function Egress() {
  const { data, error, loading, reload } = useApi<any>('/api/egress', [], 8000)
  const [sel, setSel] = useState<number | null>(null)
  const [test, setTest] = useState<any>(null)
  const [busy, setBusy] = useState(false)

  const runValidation = async () => {
    setBusy(true)
    try {
      const dirty = await post('/api/egress/validate', {
        events: [{ event_id: 'evt_t1', host: 'db01', metric: 'cpu_pct', value: 61,
          password: 'Sup3rS3cret!', raw_log: 'user=ops@acme.io token=abc', customer_email: 'ops@acme.io' }],
      })
      setTest(dirty)
    } catch (e: any) { setTest({ error: e.message }) }
    setBusy(false)
  }

  if (loading) return <Loading rows={3} />
  if (error) return <ErrorNote message={error} />

  const recs = data.records || []
  const current = sel !== null ? recs.find((r: any) => r.id === sel) : recs[0]

  return (
    <div>
      <PageHead eyebrow="Egress Proof Panel" title="Every byte that left, provable"
        sub="Exact outgoing JSON, approved fields, redaction results, collector identity, destination, transfer timestamp, status and audit history — per batch."
        right={<><span className="chip border-mint/30 bg-mint/10 text-mint">{data.summary.success_rate}% delivered</span><EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Batches" value={data.summary.total} accent="#38bdf8" icon="⇱" hint="lifetime egress records" />
        <Kpi label="Delivered" value={data.summary.delivered} accent="#22c55e" icon="✓" hint="acknowledged by SaaS" />
        <Kpi label="Bytes out" value={fmtBytes(data.summary.bytes_out)} accent="#8b5cf6" icon="▤" hint="approved metadata only" />
        <Kpi label="Destination" value="1" unit="host" accent="#2dd4bf" icon="☁" hint={data.destination.replace('https://', '')} />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[340px_1fr]">
        <Card className="overflow-hidden">
          <CardHead title="Transfer log" sub="Newest first" right={<button className="btn btn-xs" onClick={reload}>↻</button>} />
          <div className="max-h-[560px] divide-y divide-line/60 overflow-y-auto">
            {recs.length === 0 && <Empty text="No egress batch recorded yet." />}
            {recs.map((r: any) => (
              <button key={r.id} onClick={() => setSel(r.id)}
                className={`block w-full px-4 py-2.5 text-left transition-colors ${(sel ?? recs[0]?.id) === r.id ? 'bg-sky/10' : 'hover:bg-white/[0.03]'}`}>
                <div className="flex items-center justify-between">
                  <span className="mono text-[10.5px] text-slate-300">batch #{r.id}</span>
                  <span className={`chip ${r.status === 'delivered' ? 'border-lime/30 bg-lime/10 text-lime' : 'border-amber/30 bg-amber/10 text-amber'}`}>{r.status}</span>
                </div>
                <div className="mt-0.5 flex items-center justify-between text-[9.5px] text-slate-500">
                  <span className="mono">{r.collector_id}</span>
                  <span>{fmtBytes(r.bytes)} · {timeAgo(r.ts)}</span>
                </div>
              </button>
            ))}
          </div>
        </Card>

        <div className="space-y-4">
          {current && (
            <>
              <Card>
                <CardHead title={`Batch #${current.id} · transfer proof`} sub={current.ack || 'no acknowledgement'} />
                <div className="grid gap-2 p-4 sm:grid-cols-3">
                  {[
                    ['Collector identity', current.collector_id],
                    ['Destination', current.destination.replace('https://', '')],
                    ['Timestamp (UTC)', current.ts],
                    ['Status', current.status],
                    ['Size', fmtBytes(current.bytes)],
                    ['Attempts', current.attempts],
                    ['Checksum', current.checksum?.slice(0, 16) + '…'],
                    ['Approved fields', `${current.approved_fields?.length || 0}`],
                    ['Dropped fields', `${current.dropped_fields?.length || 0}`],
                  ].map(([k, v]) => (
                    <div key={k} className="rounded-lg border border-line bg-ink-900/60 px-2.5 py-1.5">
                      <div className="text-[9.5px] uppercase tracking-wider text-slate-600">{k}</div>
                      <div className="mono mt-0.5 truncate text-[10.5px] text-slate-300">{String(v)}</div>
                    </div>
                  ))}
                </div>
              </Card>

              <div className="grid gap-4 lg:grid-cols-2">
                <Card>
                  <CardHead title="Exact outgoing JSON" sub="This is precisely what crossed the boundary" />
                  <div className="p-4"><Json value={current.payload} max={30} /></div>
                </Card>
                <Card>
                  <CardHead title="Redaction results" sub={`${current.redaction_report?.length || 0} entries for this batch`} />
                  <div className="p-4">
                    {current.redaction_report?.length ? <Json value={current.redaction_report} max={22} />
                      : <div className="text-[11.5px] text-slate-500">No sensitive value matched in this batch — the source events contained no PII or credential material.</div>}
                    {current.dropped_fields?.length > 0 && (
                      <div className="mt-3">
                        <div className="label mb-1">Dropped / blocked</div>
                        <Json value={current.dropped_fields} max={10} />
                      </div>
                    )}
                  </div>
                </Card>
              </div>
            </>
          )}

          <Card>
            <CardHead title="Boundary enforcement test" sub="Sends a deliberately dirty event through the validator"
              right={<button className="btn btn-xs btn-primary" onClick={runValidation} disabled={busy}>{busy ? '…' : 'Run test'}</button>} />
            <div className="p-4">
              {!test && <div className="text-[11.5px] text-slate-500">Run the test to see the real verdict from the server-side validator.</div>}
              {test && (
                <div className="space-y-2">
                  <div className={`rounded-lg border px-3 py-2 text-[11.5px] font-medium ${test.allowed_to_transmit === false ? 'border-rose/30 bg-rose/10 text-rose' : 'border-lime/30 bg-lime/10 text-lime'}`}>
                    {test.verdict || test.error}
                  </div>
                  <Json value={test} max={18} />
                </div>
              )}
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}
