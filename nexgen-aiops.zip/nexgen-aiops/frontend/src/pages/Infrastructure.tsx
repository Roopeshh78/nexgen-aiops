import React from 'react'
import { fmtNum } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, EnvTag, ErrorNote, Kpi, Loading, PageHead, Progress,
  StateBadge, Table, Td, TrendChart } from '../components/ui'

const ACC: Record<string, string> = { Excellent: '#22c55e', Good: '#38bdf8', Fair: '#f59e0b', Poor: '#f43f5e' }

export default function Infrastructure() {
  const { data, error, loading } = useApi<any>('/api/infra', [], 8000)
  if (loading) return <Loading rows={4} />
  if (error) return <ErrorNote message={error} />
  const s = data.series || {}
  const servers = data.servers || []
  const avg = (k: string) => {
    const vals = servers.map((x: any) => x.metrics?.[k]).filter((v: any) => typeof v === 'number')
    return vals.length ? vals.reduce((a: number, b: number) => a + b, 0) / vals.length : 0
  }
  return (
    <div>
      <PageHead eyebrow="Infrastructure Observability" title="Compute, storage and process health"
        sub="Per-host CPU, memory, disk, uptime, process health and service availability — collected locally and aggregated before egress."
        right={<><span className="chip mono">{servers.length} hosts</span><EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Fleet CPU" value={avg('cpu_pct').toFixed(1)} unit="%" accent="#38bdf8" trend={s.cpu_pct} icon="▤" hint="average across collectors" />
        <Kpi label="Fleet memory" value={avg('mem_pct').toFixed(1)} unit="%" accent="#8b5cf6" trend={s.mem_pct} icon="▯" hint="resident working set" />
        <Kpi label="Disk utilisation" value={avg('disk_pct').toFixed(1)} unit="%" accent="#f59e0b" trend={s.disk_pct} icon="▣" hint="data volumes" />
        <Kpi label="Process health" value={avg('proc_health').toFixed(1)} unit="/100" accent="#22c55e" trend={s.proc_health} icon="◉" hint="supervisor check pass rate" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card><CardHead title="CPU & memory" sub="Fleet average, 48 samples" />
          <div className="card-pad"><TrendChart data={s.cpu_pct} color="#38bdf8" label="CPU %" unit="%" /></div></Card>
        <Card><CardHead title="Disk utilisation" sub="Watch for write amplification" />
          <div className="card-pad"><TrendChart data={s.disk_pct} color="#f59e0b" label="Disk %" unit="%" /></div></Card>
      </div>

      <Card className="mt-4">
        <CardHead title="Host inventory" sub="Resource utilisation, uptime and process state per monitored node" />
        <Table head={['Host', 'Collector', 'Region', 'CPU', 'Memory', 'Disk', 'Uptime', 'Process', 'Availability', 'State']}>
          {servers.map((sv: any) => (
            <tr key={sv.id} className="row-hover">
              <Td className="mono font-medium text-slate-200">{sv.host}</Td>
              <Td className="text-slate-400">{sv.name}</Td>
              <Td className="text-slate-500">{sv.region}</Td>
              {['cpu_pct', 'mem_pct', 'disk_pct'].map(k => (
                <Td key={k}>
                  <div className="flex items-center gap-2">
                    <span className="w-9 text-[11px] text-slate-300">{fmtNum(sv.metrics?.[k], 1)}</span>
                    <div className="w-14"><Progress value={sv.metrics?.[k] || 0} color={(sv.metrics?.[k] || 0) > 88 ? '#f43f5e' : (sv.metrics?.[k] || 0) > 75 ? '#f59e0b' : '#38bdf8'} /></div>
                  </div>
                </Td>
              ))}
              <Td className="text-slate-400">{sv.uptime_human}</Td>
              <Td>
                <span className={`text-[11px] font-medium ${sv.process_health === 'healthy' ? 'text-lime' : 'text-amber'}`}>
                  {sv.process_health}
                </span>
              </Td>
              <Td className="text-slate-300">{fmtNum(sv.metrics?.svc_availability_pct, 3)}%</Td>
              <Td><StateBadge state={sv.health.state} score={sv.health.score} /></Td>
            </tr>
          ))}
        </Table>
      </Card>
    </div>
  )
}
