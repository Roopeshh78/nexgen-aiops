import React from 'react'
import { fmtNum } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, EnvTag, ErrorNote, Kpi, Loading, PageHead, Table, Td, TrendChart } from '../components/ui'

export default function Distributed() {
  const { data, error, loading } = useApi<any>('/api/distributed', [], 8000)
  if (loading) return <Loading rows={4} />
  if (error) return <ErrorNote message={error} />
  const s = data.series || {}
  const last = (a: any[]) => (a?.length ? a[a.length - 1].v : 0)
  const maxRps = Math.max(...data.flow.map((f: any) => f.rps))

  return (
    <div>
      <PageHead eyebrow="Distributed Systems" title="Replication lag, queue depth and request flow"
        sub="Cross-service dependency health for the distributed tier: replication lag, message queue depth and end-to-end request flow through the service graph."
        right={<><span className="chip mono">{data.services.length} services</span><EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Replication lag" value={fmtNum(last(s.replication_lag_ms), 0)} unit="ms" accent="#8b5cf6" trend={s.replication_lag_ms} hint="primary → replica" />
        <Kpi label="Queue depth" value={fmtNum(last(s.queue_depth), 0)} unit="msgs" accent="#f59e0b" trend={s.queue_depth} hint="event bus backlog" />
        <Kpi label="p95 across services" value={fmtNum(last(s.api_p95_ms), 0)} unit="ms" accent="#38bdf8" trend={s.api_p95_ms} hint="end-to-end" />
        <Kpi label="Active flows" value={data.flow.length} accent="#2dd4bf" icon="⇄" hint="graph edges observed" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card><CardHead title="Replication lag" sub="Sustained lag above 4s indicates replica pressure" />
          <div className="card-pad"><TrendChart data={s.replication_lag_ms} color="#8b5cf6" label="Lag ms" /></div></Card>
        <Card><CardHead title="Queue depth" sub="Backlog growth precedes consumer failure" />
          <div className="card-pad"><TrendChart data={s.queue_depth} color="#f59e0b" label="Messages" /></div></Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1.1fr_1fr]">
        <Card>
          <CardHead title="Request flow" sub="Observed call graph, edge weight = requests per second" />
          <div className="space-y-2 p-5">
            {data.flow.map((f: any) => (
              <div key={`${f.from}-${f.to}`} className="flex items-center gap-3">
                <span className="mono w-28 shrink-0 text-right text-[11px] text-slate-400">{f.from}</span>
                <div className="relative h-6 flex-1 rounded-md bg-ink-900">
                  <div className="absolute inset-y-0 left-0 rounded-md bg-gradient-to-r from-sky/50 to-violet/40" style={{ width: `${(f.rps / maxRps) * 100}%` }} />
                  <span className="absolute inset-0 grid place-items-center text-[10px] font-medium text-white/80">→</span>
                </div>
                <span className="mono w-24 text-[11px] text-slate-400">{f.to}</span>
                <span className="mono w-16 text-right text-[11px] text-slate-300">{f.rps} rps</span>
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <CardHead title="Service dependency health" sub="Per-service lag and backlog" />
          <Table head={['Service', 'Region', 'Lag', 'Queue', 'Signal']}>
            {data.services.map((sv: any, i: number) => (
              <tr key={i} className="row-hover">
                <Td className="font-medium text-slate-200">{sv.name}</Td>
                <Td className="text-slate-500">{sv.region}</Td>
                <Td className={sv.replication_lag_ms > 1200 ? 'text-amber' : 'text-slate-300'}>{fmtNum(sv.replication_lag_ms, 0)} ms</Td>
                <Td className={sv.queue_depth > 5000 ? 'text-amber' : 'text-slate-300'}>{fmtNum(sv.queue_depth)}</Td>
                <Td>
                  <span className={`text-[10.5px] font-semibold ${sv.replication_lag_ms > 1200 || sv.queue_depth > 5000 ? 'text-amber' : 'text-lime'}`}>
                    {sv.replication_lag_ms > 1200 || sv.queue_depth > 5000 ? 'degraded' : 'nominal'}
                  </span>
                </Td>
              </tr>
            ))}
          </Table>
        </Card>
      </div>
    </div>
  )
}
