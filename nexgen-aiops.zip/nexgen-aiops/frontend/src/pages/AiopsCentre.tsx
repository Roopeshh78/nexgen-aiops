import React from 'react'
import { Link } from 'react-router-dom'
import { fmtNum } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, EnvTag, ErrorNote, Loading, PageHead, Progress } from '../components/ui'

const ICONS: Record<string, string> = {
  anomaly: '◈', baseline: '▤', predict: '↗', rca: '⌖', correlation: '⇄',
  dedupe: '⧉', noise: '✦', risk: '⚖', capacity: '▦', explain: '✧',
}

export default function AiopsCentre() {
  const { data, error, loading } = useApi<any>('/api/aiops/modules', [], 10000)
  if (loading) return <Loading rows={4} />
  if (error) return <ErrorNote message={error} />
  const noise = data.modules.find((m: any) => m.key === 'noise')

  return (
    <div>
      <PageHead eyebrow="AIOps Intelligence Centre" title="Ten modules, one decision engine"
        sub="Every module runs against allow-listed metadata inside the analytics tier. Each output is explainable: signal, method, contribution and recommended action."
        right={<><span className="chip border-mint/30 bg-mint/10 text-mint">{data.modules.length} modules active</span><EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          ['Modules active', data.modules.filter((m: any) => m.status === 'active').length, '#22c55e'],
          ['Noise reduction', `${noise?.outputs ?? 0}%`, '#8b5cf6'],
          ['Signals processed', fmtNum(data.modules.reduce((a: number, m: any) => a + (m.processed || 0), 0)), '#38bdf8'],
          ['Decisions emitted', fmtNum(data.modules.reduce((a: number, m: any) => a + (m.outputs || 0), 0)), '#2dd4bf'],
        ].map(([l, v, c]) => (
          <Card key={l as string} className="card-pad">
            <div className="label">{l as string}</div>
            <div className="mt-2 text-[24px] font-semibold" style={{ color: c as string }}>{v as any}</div>
          </Card>
        ))}
      </div>

      <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {data.modules.map((m: any) => (
          <Card key={m.key} className="card-pad group transition-colors hover:border-sky/30">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                <span className="grid h-8 w-8 place-items-center rounded-lg bg-sky/10 text-[14px] text-sky">{ICONS[m.key] || '✦'}</span>
                <div>
                  <div className="text-[12.5px] font-semibold text-slate-100">{m.name}</div>
                  <div className="mono text-[10px] text-slate-500">{m.model}</div>
                </div>
              </div>
              <span className="chip border-mint/25 bg-mint/10 text-mint">{m.status}</span>
            </div>
            <p className="mt-2.5 text-[11px] leading-relaxed text-slate-400">{m.detail}</p>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <div className="rounded-lg border border-line bg-ink-900/60 px-2.5 py-1.5">
                <div className="text-[9.5px] uppercase tracking-wider text-slate-600">processed</div>
                <div className="text-[13px] font-semibold text-slate-200">{fmtNum(m.processed)}</div>
              </div>
              <div className="rounded-lg border border-line bg-ink-900/60 px-2.5 py-1.5">
                <div className="text-[9.5px] uppercase tracking-wider text-slate-600">outputs</div>
                <div className="text-[13px] font-semibold text-slate-200">{fmtNum(m.outputs)}</div>
              </div>
            </div>
            {m.key === 'noise' && <div className="mt-2"><Progress value={m.outputs} color="#8b5cf6" /></div>}
          </Card>
        ))}
      </div>

      <Card className="mt-4">
        <CardHead title="Decision path" sub="How one raw signal becomes one explainable recommendation" />
        <div className="flex flex-wrap items-stretch gap-2 p-5">
          {[
            ['01', 'Ingest', 'Metadata arrives, allow-list enforced'],
            ['02', 'Baseline', '40-sample rolling mean / stdev'],
            ['03', 'Detect', 'Z-score + threshold breach'],
            ['04', 'Dedupe', 'Fingerprint = metric::collector'],
            ['05', 'Correlate', 'Affinity by host / service'],
            ['06', 'Explain', 'What, why, signals, action'],
            ['07', 'Recommend', 'Human-in-the-loop approval'],
          ].map(([n, t, d], i, arr) => (
            <React.Fragment key={n}>
              <div className="min-w-[132px] flex-1 rounded-xl border border-line bg-ink-900/60 p-3">
                <div className="mono text-[10px] text-sky">{n}</div>
                <div className="mt-0.5 text-[11.5px] font-semibold text-slate-200">{t}</div>
                <div className="mt-0.5 text-[10px] leading-snug text-slate-500">{d}</div>
              </div>
              {i < arr.length - 1 && <div className="hidden items-center text-slate-700 sm:flex">→</div>}
            </React.Fragment>
          ))}
        </div>
      </Card>

      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[['Anomaly detail', '/anomalies'], ['Root cause', '/rca'], ['Capacity', '/capacity'], ['Recommendations', '/recommendations']].map(([t, to]) => (
          <Link key={t} to={to} className="btn justify-center">{t} →</Link>
        ))}
      </div>
    </div>
  )
}
