import React from 'react'
import { fmtNum } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, EnvTag, ErrorNote, Kpi, Loading, MultiChart, PageHead, SevBadge, Table, Td } from '../components/ui'

export default function Network() {
  const { data, error, loading } = useApi<any>('/api/network', [], 8000)
  if (loading) return <Loading rows={4} />
  if (error) return <ErrorNote message={error} />
  const last = (arr: any[]) => (arr?.length ? arr[arr.length - 1].v : 0)
  return (
    <div>
      <PageHead eyebrow="Network Observability" title="Path performance and link integrity"
        sub="Latency, packet loss, bandwidth, throughput, connectivity and anomaly trends across every monitored network segment."
        right={<><span className="chip">{data.nodes.length} nodes</span><EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Latency" value={fmtNum(last(data.latency), 1)} unit="ms" accent="#2dd4bf" trend={data.latency} hint="round-trip time" />
        <Kpi label="Packet loss" value={fmtNum(last(data.packet_loss), 2)} unit="%" accent="#f43f5e" trend={data.packet_loss} hint="transit link" />
        <Kpi label="Bandwidth" value={fmtNum(last(data.bandwidth), 0)} unit="Mbps" accent="#38bdf8" trend={data.bandwidth} hint="sustained rate" />
        <Kpi label="Throughput" value={fmtNum(last(data.throughput), 0)} unit="req/s" accent="#8b5cf6" trend={data.throughput} hint="application requests" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1.4fr_1fr]">
        <Card><CardHead title="Latency & packet loss" sub="Correlated view — loss precedes latency inflation" />
          <div className="card-pad">
            <MultiChart series={[
              { name: 'RTT ms', color: '#2dd4bf', data: data.latency },
              { name: 'Loss %', color: '#f43f5e', data: data.packet_loss },
            ]} height={250} />
          </div>
        </Card>
        <Card>
          <CardHead title="Trend analysis" sub="Least-squares slope over the last 60 samples" />
          <div className="divide-y divide-line/60">
            {data.trends.map((t: any) => (
              <div key={t.metric} className="flex items-center justify-between px-5 py-3">
                <div>
                  <div className="text-[12px] font-medium text-slate-200">{t.metric}</div>
                  <div className="text-[10.5px] text-slate-500">slope {t.slope}/step · {t.unit}</div>
                </div>
                <div className="text-right">
                  <div className="text-[14px] font-semibold text-white">{fmtNum(t.current, 2)}</div>
                  <div className={`text-[10px] font-semibold uppercase tracking-wider ${t.trend === 'rising' ? 'text-amber' : t.trend === 'falling' ? 'text-sky' : 'text-slate-500'}`}>{t.trend}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHead title="Network anomalies" sub="Deviations against the 40-sample baseline" />
          <Table head={['Metric', 'Value', 'Baseline', 'Z-score', 'Severity']}>
            {data.anomalies.length === 0 && <tr><Td className="text-slate-500">No anomalies detected on the monitored links.</Td></tr>}
            {data.anomalies.map((a: any, i: number) => (
              <tr key={i} className="row-hover">
                <Td className="text-slate-200">{a.metric}</Td>
                <Td className="mono">{fmtNum(a.value, 2)}</Td>
                <Td className="mono text-slate-500">{fmtNum(a.baseline, 2)}</Td>
                <Td className={Math.abs(a.z_score) >= 3 ? 'text-rose' : 'text-amber'}>{a.z_score}</Td>
                <Td><SevBadge severity={a.severity} /></Td>
              </tr>
            ))}
          </Table>
        </Card>
        <Card>
          <CardHead title="Connectivity" sub="Link state from collector to ingress" />
          <div className="divide-y divide-line/60">
            {data.connectivity.map((c: any) => (
              <div key={c.link} className="flex items-center justify-between px-5 py-2.5">
                <span className="mono text-[11.5px] text-slate-300">{c.link}</span>
                <div className="flex items-center gap-2">
                  <span className="text-[10.5px] text-slate-500">{c.region}</span>
                  <span className={`chip ${c.status === 'up' ? 'border-mint/30 bg-mint/10 text-mint' : 'border-rose/30 bg-rose/10 text-rose'}`}>{c.status}</span>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}
