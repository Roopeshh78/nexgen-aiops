import React, { useState } from 'react'
import { post } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, EnvTag, ErrorNote, Json, Loading, PageHead } from '../components/ui'

const SAMPLE = {
  event_id: 'evt_demo_001', host: 'db01.eu-west-1', service: 'postgres-primary',
  metric: 'cpu_pct', value: 61.4, unit: '%', observed_at: '2026-11-20T09:14:03Z',
  raw_log: 'user=ops.dba@acme-fg.com password=Sup3rS3cret! token=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJvcHMifQ.abc123def456',
  credentials: { password: 'Sup3rS3cret!', api_key: 'sk-live-9f2b7e11c4' },
  customer_email: 'oncall.dba@acme-fg.com', ip_address: '10.4.2.21',
  request_body: '{"card":"4111 1111 1111 1111"}', env: 'prod',
}

export default function Privacy() {
  const { data, error, loading } = useApi<any>('/api/privacy/policy')
  const [input, setInput] = useState(JSON.stringify(SAMPLE, null, 2))
  const [result, setResult] = useState<any>(null)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)

  const run = async () => {
    setBusy(true); setErr(''); setResult(null)
    try {
      const parsed = JSON.parse(input)
      setResult(await post('/api/privacy/inspect', parsed))
    } catch (e: any) { setErr(e.message || 'Invalid JSON') }
    setBusy(false)
  }

  if (loading) return <Loading rows={3} />
  if (error) return <ErrorNote message={error} />

  return (
    <div>
      <PageHead eyebrow="Privacy & Data Protection" title="Two-tier boundary, enforced by construction"
        sub={data.invariant}
        right={<><span className="chip border-mint/30 bg-mint/10 text-mint">{data.allowed_fields.length} allow-listed fields</span><EnvTag /></>} />

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHead title="Customer environment" sub="Everything below runs on-premise" />
          <div className="space-y-1.5 p-4">
            {data.two_tier.customer_environment.map((s: string, i: number) => (
              <div key={s} className="flex items-center gap-2.5 rounded-lg border border-line bg-ink-900/60 px-3 py-1.5">
                <span className="mono w-5 text-[10px] text-sky">{String(i + 1).padStart(2, '0')}</span>
                <span className="text-[11.5px] text-slate-300">{s}</span>
                {s === 'Approved metadata' && <span className="ml-auto chip border-amber/30 bg-amber/10 text-amber">boundary</span>}
              </div>
            ))}
          </div>
        </Card>
        <Card>
          <CardHead title="Central SaaS" sub="Receives approved metadata only" />
          <div className="space-y-1.5 p-4">
            {data.two_tier.central_saas.map((s: string, i: number) => (
              <div key={s} className="flex items-center gap-2.5 rounded-lg border border-line bg-ink-900/60 px-3 py-1.5">
                <span className="mono w-5 text-[10px] text-violet">{String(i + 1).padStart(2, '0')}</span>
                <span className="text-[11.5px] text-slate-300">{s}</span>
              </div>
            ))}
          </div>
          <div className="border-t border-line px-4 py-3">
            <div className="label mb-1.5">Never leaves the customer environment</div>
            <div className="flex flex-wrap gap-1">
              {data.two_tier.never_leaves.map((x: string) => (
                <span key={x} className="chip border-rose/25 bg-rose/10 text-rose">{x}</span>
              ))}
            </div>
          </div>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHead title="Live redaction inspector" sub="Paste any object — the real collector pipeline returns what would actually transit" />
        <div className="grid gap-4 p-4 lg:grid-cols-2">
          <div>
            <textarea className="input mono h-[280px] resize-none leading-relaxed" value={input} onChange={e => setInput(e.target.value)} spellCheck={false} />
            <div className="mt-2 flex items-center gap-2">
              <button className="btn btn-primary" onClick={run} disabled={busy}>{busy ? 'Running pipeline…' : 'Run pipeline'}</button>
              <button className="btn" onClick={() => { setInput(JSON.stringify(SAMPLE, null, 2)); setResult(null) }}>Reset sample</button>
              {err && <span className="text-[11px] text-rose">{err}</span>}
            </div>
          </div>
          <div>
            {!result && <div className="flex h-[280px] items-center justify-center rounded-lg border border-dashed border-line text-[11.5px] text-slate-500">Output appears here after the pipeline runs.</div>}
            {result && (
              <div className="space-y-2">
                <div className="flex flex-wrap gap-1.5">
                  <span className="chip">ingested {result.stage_counts.ingested}</span>
                  <span className="chip border-rose/25 bg-rose/10 text-rose">{result.stage_counts.redactions} redactions</span>
                  <span className="chip">approved {result.stage_counts.approved}</span>
                  <span className="chip">sha256 {result.checksum.slice(0, 12)}</span>
                </div>
                <Json value={result.output} max={26} />
                <details className="rounded-lg border border-line bg-ink-900/60 p-2.5">
                  <summary className="cursor-pointer text-[11px] text-slate-400">redaction report ({result.redaction_report.length} entries)</summary>
                  <div className="mt-2"><Json value={result.redaction_report} max={18} /></div>
                </details>
              </div>
            )}
          </div>
        </div>
      </Card>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHead title="Allow-list (egress schema)" sub="The envelope is built from these fields only" />
          <div className="flex flex-wrap gap-1.5 p-4">
            {data.allowed_fields.map((f: string) => <span key={f} className="chip border-mint/25 bg-mint/10 font-mono text-mint">{f}</span>)}
          </div>
        </Card>
        <Card>
          <CardHead title="Forbidden fields" sub="Blocked even if a caller sends them" />
          <div className="flex flex-wrap gap-1.5 p-4">
            {data.forbidden_fields.map((f: string) => <span key={f} className="chip border-rose/20 bg-rose/5 font-mono text-rose/80">{f}</span>)}
          </div>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHead title="Redaction rules" sub={`${data.redaction_rules.length} pattern classes applied before aggregation`} />
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead><tr className="border-b border-line">
              {['Rule', 'Pattern', 'Replacement'].map(h => (
                <th key={h} className="px-4 py-2 text-[10px] font-semibold uppercase tracking-wider text-slate-500">{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {data.redaction_rules.map((r: any) => (
                <tr key={r.rule} className="row-hover">
                  <td className="border-b border-line/50 px-4 py-2 text-[11.5px] font-medium text-slate-200">{r.rule}</td>
                  <td className="mono border-b border-line/50 px-4 py-2 text-[10.5px] text-slate-500">{r.pattern}</td>
                  <td className="mono border-b border-line/50 px-4 py-2 text-[10.5px] text-amber">{r.replacement}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  )
}
