import React from 'react'
import { fmtNum } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, EnvTag, ErrorNote, Kpi, Loading, PageHead, Progress, SevBadge, Table, Td, TrendChart } from '../components/ui'

export default function Security() {
  const { data, error, loading } = useApi<any>('/api/security', [], 8000)
  if (loading) return <Loading rows={4} />
  if (error) return <ErrorNote message={error} />
  const last = (a: any[]) => (a?.length ? a[a.length - 1].v : 0)
  const crit = data.events.filter((e: any) => e.severity === 'critical').length

  return (
    <div>
      <PageHead eyebrow="Security Intelligence" title="Authentication anomalies and risk posture"
        sub="Failed logins, credential-stuffing bursts, collector silence and authentication anomalies. Identity material is redacted before it ever leaves the host."
        right={<><span className="chip border-rose/30 bg-rose/10 text-rose">risk {data.risk.overall}/100</span><EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Failed logins" value={fmtNum(last(data.failed_logins), 0)} unit="/min" accent="#f43f5e" trend={data.failed_logins} hint="rolling window" />
        <Kpi label="Auth anomaly score" value={fmtNum(last(data.auth_anomaly), 0)} unit="/100" accent="#f59e0b" trend={data.auth_anomaly} hint="behavioural deviation" />
        <Kpi label="Critical events" value={crit} hint={`${data.events.length} classified events`} accent="#f43f5e" icon="⛨" />
        <Kpi label="Values redacted" value={fmtNum(data.redaction.total_matches)} hint="credentials, PII, infrastructure" accent="#8b5cf6" icon="⧉" />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1.35fr_1fr]">
        <Card><CardHead title="Failed authentication volume" sub="Burst detection uses velocity against the learned baseline" />
          <div className="card-pad"><TrendChart data={data.failed_logins} color="#f43f5e" label="Failed logins / min" /></div>
        </Card>
        <Card>
          <CardHead title="Risk score composition" sub={`Overall ${data.risk.overall}/100`} />
          <div className="card-pad">
            <div className="mb-3"><Progress value={data.risk.overall} color={data.risk.overall > 60 ? '#f43f5e' : data.risk.overall > 35 ? '#f59e0b' : '#22c55e'} /></div>
            <div className="space-y-2">
              {data.risk.factors.map((f: string, i: number) => (
                <div key={f} className="flex items-center justify-between rounded-lg border border-line bg-ink-900/60 px-3 py-2">
                  <span className="text-[11.5px] text-slate-300">{f}</span>
                  <span className="mono text-[11px] text-slate-500">w {(0.45 - i * 0.1).toFixed(2)}</span>
                </div>
              ))}
            </div>
            <div className="mt-3 rounded-lg border border-line bg-ink-900/60 p-3 text-[10.5px] leading-relaxed text-slate-500">
              Risk = severity × blast radius × freshness. A stale collector contributes silence risk, never a healthy assumption.
            </div>
          </div>
        </Card>
      </div>

      <Card className="mt-4">
        <CardHead title="Classified security events" sub="Detection rationale and the redaction applied before egress" />
        <Table head={['Class', 'Severity', 'Host', 'Count', 'Risk', 'Detection', 'Redaction applied']}>
          {data.events.length === 0 && <tr><Td className="text-slate-500">No suspicious authentication activity in the current window.</Td></tr>}
          {data.events.map((e: any, i: number) => (
            <tr key={i} className="row-hover">
              <Td className="font-medium text-slate-200">{e.class.replace(/_/g, ' ')}</Td>
              <Td><SevBadge severity={e.severity} /></Td>
              <Td className="mono text-slate-400">{e.host}</Td>
              <Td className="mono">{e.count}</Td>
              <Td className={e.risk_score > 70 ? 'text-rose' : 'text-amber'}>{e.risk_score}</Td>
              <Td className="whitespace-normal text-slate-400" >{e.detection}</Td>
              <Td className="whitespace-normal text-slate-500">{e.redaction}</Td>
            </tr>
          ))}
        </Table>
      </Card>

      <Card className="mt-4">
        <CardHead title="Redaction classes enforced locally" sub="Pattern-based, applied before aggregation and policy check" />
        <div className="grid gap-3 p-5 sm:grid-cols-3">
          {data.redaction.classes.map((c: any) => (
            <div key={c.class} className="rounded-xl border border-line bg-ink-900/60 p-3">
              <div className="text-[12px] font-semibold capitalize text-slate-200">{c.class}</div>
              <div className="mt-1.5 flex flex-wrap gap-1">
                {c.examples.map((x: string) => <span key={x} className="chip">{x}</span>)}
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  )
}
