import React, { useState } from 'react'
import { clock, patch } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, Empty, EnvTag, ErrorNote, Kpi, Loading, PageHead, Progress, SevBadge, Table, Td } from '../components/ui'

const NEXT: Record<string, string[]> = {
  open: ['investigating', 'mitigated', 'closed'],
  investigating: ['mitigated', 'closed'],
  mitigated: ['closed', 'investigating'],
  closed: ['investigating'],
}

export default function Incidents() {
  const { data, error, loading, reload } = useApi<any>('/api/incidents', [], 8000)
  const [busy, setBusy] = useState('')
  if (loading) return <Loading rows={3} />
  if (error) return <ErrorNote message={error} />

  const move = async (id: string, status: string) => {
    setBusy(id)
    try { await patch(`/api/incidents/${id}`, { status }); await reload() } catch { /* surfaced by reload */ }
    setBusy('')
  }

  const incs = data.incidents || []
  return (
    <div>
      <PageHead eyebrow="Incident Management" title="Correlated incidents and lifecycle"
        sub="Incidents are opened by the correlation engine when alerts share a failure domain. Status transitions are validated server-side and written to the audit chain."
        right={<><span className="chip border-rose/30 bg-rose/10 text-rose">{data.open} active</span><EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Active incidents" value={data.open} accent="#f43f5e" icon="⚠" hint="open + investigating" />
        <Kpi label="Total correlated" value={incs.length} accent="#38bdf8" icon="⇄" hint="lifetime in this tenant" />
        <Kpi label="Closed" value={incs.filter((i: any) => i.status === 'closed').length} accent="#22c55e" icon="✓" hint="resolved" />
        <Kpi label="MTTR" value={data.mttr_minutes} unit="min" accent="#8b5cf6" icon="⏱" hint="rolling estimate" />
      </div>

      <Card className="mt-4">
        <CardHead title="Incident register" sub="Status transitions are enforced by the API" />
        {incs.length === 0 ? <Empty /> : (
          <Table head={['Incident', 'Severity', 'Status', 'Alerts', 'Confidence', 'Opened', 'Owner', 'Transitions']}>
            {incs.map((i: any) => (
              <tr key={i.id} className="row-hover">
                <Td>
                  <div className="font-medium text-slate-200">{i.title}</div>
                  <div className="mono text-[10px] text-slate-500">{i.id}</div>
                </Td>
                <Td><SevBadge severity={i.severity} /></Td>
                <Td>
                  <span className={`chip ${i.status === 'closed' ? 'border-lime/30 bg-lime/10 text-lime' : i.status === 'mitigated' ? 'border-sky/30 bg-sky/10 text-sky' : 'border-amber/30 bg-amber/10 text-amber'}`}>{i.status}</span>
                </Td>
                <Td className="mono">{i.alerts}</Td>
                <Td>
                  <div className="flex items-center gap-2">
                    <span className="w-8 text-[11px] text-slate-300">{(i.confidence * 100).toFixed(0)}%</span>
                    <div className="w-14"><Progress value={i.confidence * 100} color="#38bdf8" /></div>
                  </div>
                </Td>
                <Td className="mono text-slate-500">{clock(i.opened_at)}</Td>
                <Td className="text-slate-400">{i.owner}</Td>
                <Td>
                  <div className="flex gap-1">
                    {(NEXT[i.status] || []).map((s: string) => (
                      <button key={s} className="btn btn-xs" disabled={busy === i.id} onClick={() => move(i.id, s)}>{s}</button>
                    ))}
                  </div>
                </Td>
              </tr>
            ))}
          </Table>
        )}
      </Card>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        {incs.filter((i: any) => i.status !== 'closed').slice(0, 4).map((i: any) => (
          <Card key={i.id} className="card-pad">
            <div className="flex items-start justify-between gap-2">
              <div className="text-[12.5px] font-semibold text-slate-100">{i.title}</div>
              <SevBadge severity={i.severity} />
            </div>
            <p className="mt-1.5 text-[11px] leading-relaxed text-slate-400">{i.root_cause}</p>
            <p className="mt-1.5 text-[10.5px] leading-relaxed text-slate-500">{i.summary}</p>
            <div className="mt-2 flex flex-wrap gap-1.5">
              <span className="chip">{i.status}</span>
              <span className="chip">{i.alerts} correlated alerts</span>
              <span className="chip">conf {(i.confidence * 100).toFixed(0)}%</span>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
