import React, { useState } from 'react'
import { post, timeAgo } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, Empty, EnvTag, ErrorNote, Kpi, Loading, PageHead, Progress } from '../components/ui'

const CAT: Record<string, { color: string; icon: string }> = {
  capacity: { color: '#38bdf8', icon: '▦' }, reliability: { color: '#8b5cf6', icon: '◈' },
  security: { color: '#f43f5e', icon: '⛨' }, noise: { color: '#f59e0b', icon: '✦' },
  cost: { color: '#22c55e', icon: '◎' },
}

export default function Recommendations() {
  const { data, error, loading, reload } = useApi<any>('/api/recommendations', [], 10000)
  const [busy, setBusy] = useState('')

  const act = async (id: string, action: string) => {
    setBusy(id + action)
    try { await post(`/api/recommendations/${id}/${action}`); await reload() } catch { /* reload */ }
    setBusy('')
  }

  if (loading) return <Loading rows={3} />
  if (error) return <ErrorNote message={error} />
  const recs = data.recommendations || []
  const a = data.autonomy || {}

  return (
    <div>
      <PageHead eyebrow="Recommendations & Autonomous Operations" title="Explainable actions, human in the loop"
        sub="Each recommendation states its evidence and confidence. Nothing executes automatically in this build — approve or execute records the decision in the audit chain."
        right={<><span className="chip border-sky/30 bg-sky/10 text-sky">{a.mode}</span><EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Proposed" value={a.proposed} accent="#38bdf8" icon="✧" hint="awaiting a decision" />
        <Kpi label="Approved" value={a.approved} accent="#8b5cf6" icon="✓" hint="queued for execution" />
        <Kpi label="Executed" value={a.executed_24h} accent="#22c55e" icon="⚡" hint="last 24 hours" />
        <Kpi label="Autonomy mode" value="HITL" accent="#f59e0b" icon="⚖" hint="no unattended changes" />
      </div>

      {recs.length === 0 && <Card className="mt-4"><Empty text="No recommendation yet. Trigger a pressure scenario to generate capacity or reliability advice." /></Card>}

      <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {recs.map((r: any) => {
          const c = CAT[r.category] || CAT.reliability
          return (
            <Card key={r.id} className="card-pad flex flex-col">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="grid h-7 w-7 place-items-center rounded-lg text-[12px]" style={{ background: `${c.color}18`, color: c.color }}>{c.icon}</span>
                  <span className="chip" style={{ color: c.color, borderColor: `${c.color}44` }}>{r.category}</span>
                </div>
                <span className={`chip ${r.status === 'executed' ? 'border-lime/30 bg-lime/10 text-lime' : r.status === 'approved' ? 'border-sky/30 bg-sky/10 text-sky' : r.status === 'dismissed' ? 'border-line text-slate-500' : 'border-amber/30 bg-amber/10 text-amber'}`}>{r.status}</span>
              </div>
              <h3 className="mt-2 text-[12.5px] font-semibold leading-snug text-slate-100">{r.title}</h3>
              <p className="mt-1 flex-1 text-[11px] leading-relaxed text-slate-400">{r.detail}</p>
              <div className="mt-2.5">
                <div className="mb-1 flex items-center justify-between text-[10px] text-slate-500">
                  <span>confidence</span><span>{(r.confidence * 100).toFixed(0)}%</span>
                </div>
                <Progress value={r.confidence * 100} color={c.color} />
              </div>
              <div className="mt-2 flex flex-wrap gap-1">
                {(r.evidence || []).map((e: string, i: number) => <span key={i} className="chip">{e}</span>)}
              </div>
              <div className="mt-3 flex items-center gap-1.5">
                <button className="btn btn-xs flex-1" disabled={!!busy || r.status !== 'proposed'} onClick={() => act(r.id, 'approve')}>approve</button>
                <button className="btn btn-xs btn-primary flex-1" disabled={!!busy || r.status === 'executed'} onClick={() => act(r.id, 'execute')}>execute</button>
                <button className="btn btn-xs" disabled={!!busy || r.status === 'dismissed'} onClick={() => act(r.id, 'dismiss')}>dismiss</button>
              </div>
              <div className="mt-1.5 text-[9.5px] text-slate-600">impact {r.impact} · {timeAgo(r.created_at)}</div>
            </Card>
          )
        })}
      </div>

      <div className="mt-4 rounded-xl border border-line bg-ink-800/60 p-4 text-[11.5px] leading-relaxed text-slate-400">
        <b className="text-slate-200">Autonomy statement.</b> Execution here is a state transition recorded in the audit chain, not a change to live infrastructure.
        A production deployment would gate execution behind a change-approval workflow and a rollback plan — claiming autonomous remediation without that would be misleading.
      </div>
    </div>
  )
}
