import React, { useState } from 'react'
import { fmtNum } from '../api'
import { useApi } from '../hooks'
import { Card, CardHead, EnvTag, ErrorNote, Kpi, Loading, MultiChart, PageHead, Table, Td, TrendChart } from '../components/ui'

const METRICS = [
  ['cpu_pct', 'CPU utilisation'], ['mem_pct', 'Memory utilisation'], ['disk_pct', 'Disk utilisation'],
  ['latency_ms', 'Network latency'], ['error_rate_pct', 'Error rate'], ['api_p95_ms', 'API p95'],
]

export default function Predictive() {
  const [metric, setMetric] = useState('cpu_pct')
  const { data, error, loading } = useApi<any>(`/api/predict?metric=${metric}`, [metric], 10000)
  if (loading) return <Loading rows={3} />
  if (error) return <ErrorNote message={error} />
  const f = data.forecast || {}
  const merged = [
    ...(data.history || []).map((p: any) => ({ t: p.t, observed: p.v })),
    ...(f.points || []).map((p: any) => ({ t: `+${p.step}`, forecast: p.value, low: p.low, high: p.high })),
  ]

  return (
    <div>
      <PageHead eyebrow="Predictive Analytics" title="Forecast the breach before it happens"
        sub={f.available ? `${f.method} · ${f.samples} samples · slope ${f.slope_per_step}/step · RMSE ${f.rmse}` : 'Awaiting sufficient history for a forecast.'}
        right={<>
          <select className="input w-auto py-1.5" value={metric} onChange={e => setMetric(e.target.value)}>
            {METRICS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
          </select>
          <EnvTag /></>} />

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi label="Current" value={fmtNum(f.current, 2)} unit={data.unit} accent="#38bdf8" hint={data.label} />
        <Kpi label="Trend" value={f.trend || '—'} accent={f.trend === 'rising' ? '#f59e0b' : f.trend === 'falling' ? '#22c55e' : '#64748b'} icon="↗" hint={`slope ${f.slope_per_step}/step`} />
        <Kpi label="Projected 100%" value={f.projected_100_in_steps ? `+${f.projected_100_in_steps}` : 'beyond horizon'} unit={f.projected_100_in_steps ? 'steps' : ''} accent="#f43f5e" icon="⚡" hint={data.horizon_note} />
        <Kpi label="Soonest at risk" value={data.soonest_threshold_breach?.host?.split('.')[0] || '—'} accent="#8b5cf6" icon="▤"
          hint={data.soonest_threshold_breach ? `+${data.soonest_threshold_breach.steps} steps` : 'no host trending to ceiling'} />
      </div>

      <Card className="mt-4">
        <CardHead title={`${data.label} — observed vs forecast`} sub="Solid: observed. Dashed: projected with residual confidence band." />
        <div className="card-pad">
          <MultiChart series={[
            { name: 'observed', color: '#38bdf8', data: merged.filter(m => m.observed !== undefined).map(m => ({ t: m.t, v: m.observed })) },
            { name: 'forecast', color: '#8b5cf6', data: merged.filter(m => m.forecast !== undefined).map(m => ({ t: m.t, v: m.forecast })) },
            { name: 'upper band', color: '#475569', data: merged.filter(m => m.high !== undefined).map(m => ({ t: m.t, v: m.high })) },
            { name: 'lower band', color: '#334155', data: merged.filter(m => m.low !== undefined).map(m => ({ t: m.t, v: m.low })) },
          ]} height={300} />
        </div>
      </Card>

      <div className="mt-4 grid gap-4 lg:grid-cols-[1.2fr_1fr]">
        <Card>
          <CardHead title="Forecast table" sub={`Horizon × confidence band for ${data.label}`} />
          <Table head={['Step', 'Projected', 'Low', 'High', 'Width']}>
            {(f.points || []).map((p: any) => (
              <tr key={p.step} className="row-hover">
                <Td className="mono text-slate-400">+{p.step}</Td>
                <Td className="mono font-medium text-slate-100">{fmtNum(p.value, 2)}</Td>
                <Td className="mono text-slate-500">{fmtNum(p.low, 2)}</Td>
                <Td className="mono text-slate-500">{fmtNum(p.high, 2)}</Td>
                <Td className="text-slate-500">{fmtNum(p.high - p.low, 2)}</Td>
              </tr>
            ))}
          </Table>
        </Card>
        <Card>
          <CardHead title="Method & honesty" sub="What this model does and does not claim" />
          <div className="space-y-2.5 p-5 text-[11.5px] leading-relaxed text-slate-400">
            <p><b className="text-slate-200">Fit.</b> Ordinary least squares on the last 60 samples — deliberately simple so the output is auditable line by line.</p>
            <p><b className="text-slate-200">Band.</b> The confidence interval is RMSE × horizon factor, so uncertainty widens as the projection extends.</p>
            <p><b className="text-slate-200">Limit.</b> A linear model does not understand traffic seasonality. A production deployment needs seasonal decomposition and backtesting against labelled history.</p>
            <p className="text-slate-500">No accuracy metric is claimed here — none was measured against ground truth.</p>
          </div>
        </Card>
      </div>
    </div>
  )
}
