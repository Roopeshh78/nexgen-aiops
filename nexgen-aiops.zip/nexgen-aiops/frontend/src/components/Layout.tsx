import React, { useEffect, useState } from 'react'
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom'
import { api, clearSession, getToken, getUser, post, timeAgo } from '../api'
import { useLive } from '../hooks'

type NavItem = { to: string; label: string; icon: string }
const GROUPS: { title: string; items: NavItem[] }[] = [
  {
    title: 'Observe',
    items: [
      { to: '/', label: 'Executive Overview', icon: '◎' },
      { to: '/infrastructure', label: 'Infrastructure', icon: '▤' },
      { to: '/network', label: 'Network', icon: '⌁' },
      { to: '/application', label: 'Application', icon: '⬡' },
      { to: '/security', label: 'Security Intelligence', icon: '⛨' },
      { to: '/cloud', label: 'Cloud Observability', icon: '☁' },
      { to: '/distributed', label: 'Distributed Systems', icon: '⇄' },
    ],
  },
  {
    title: 'Intelligence',
    items: [
      { to: '/aiops', label: 'AIOps Intelligence', icon: '✦' },
      { to: '/anomalies', label: 'Anomaly Detection', icon: '◈' },
      { to: '/rca', label: 'Root Cause Analysis', icon: '⌖' },
      { to: '/incidents', label: 'Incident Management', icon: '⚠' },
      { to: '/predictive', label: 'Predictive Analytics', icon: '↗' },
      { to: '/capacity', label: 'Capacity Planning', icon: '▦' },
      { to: '/alerts', label: 'Alert Management', icon: '◔' },
    ],
  },
  {
    title: 'Govern & Prove',
    items: [
      { to: '/collectors', label: 'Collector Fleet', icon: '◉' },
      { to: '/privacy', label: 'Privacy & Protection', icon: '⧉' },
      { to: '/egress', label: 'Egress Proof Panel', icon: '⇱' },
      { to: '/tenants', label: 'Tenant Management', icon: '⛁' },
      { to: '/audit', label: 'Audit Logs', icon: '⛓' },
      { to: '/recommendations', label: 'Recommendations', icon: '✧' },
    ],
  },
]

const DEMO_SCENARIOS = [
  ['normal', 'Normal operation', '▬'],
  ['high_cpu', 'High CPU', '▮'],
  ['high_memory', 'High memory', '▯'],
  ['high_disk', 'High disk usage', '▣'],
  ['latency', 'Increased latency', '⌁'],
  ['packet_loss', 'Packet loss', '≋'],
  ['failed_logins', 'Repeated failed logins', '⚿'],
  ['collector_offline', 'Collector disconnection', '⊘'],
  ['saas_failure', 'SaaS connection failure', '☁'],
  ['recovery', 'Connection recovery', '↻'],
  ['multi_alert', 'Multiple related alerts', '⚡'],
]

export default function Layout() {
  const user = getUser()
  const nav = useNavigate()
  const loc = useLocation()
  const { tick, connected } = useLive()
  const [demoOpen, setDemoOpen] = useState(false)
  const [active, setActive] = useState<string[]>([])
  const [busy, setBusy] = useState('')
  const [mobile, setMobile] = useState(false)

  const loadScenarios = async () => {
    try { const r = await api<any>('/api/scenarios'); setActive(r.active) } catch { /* noop */ }
  }
  useEffect(() => { loadScenarios() }, [])
  useEffect(() => { setMobile(false) }, [loc.pathname])

  const trigger = async (key: string) => {
    setBusy(key)
    try { await post(`/api/scenarios/${key}`); await loadScenarios() } catch { /* noop */ }
    setBusy('')
  }

  const logout = () => { clearSession(); nav('/login') }
  if (!getToken()) { nav('/login'); return null }

  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className={`fixed z-40 flex h-screen w-[248px] flex-col border-r border-line bg-ink-900/95 backdrop-blur transition-transform lg:translate-x-0 ${mobile ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="flex items-center gap-2.5 px-5 py-5">
          <div className="relative grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-sky to-violet text-[15px] font-bold text-ink-950">
            N
            <span className="absolute -right-0.5 -top-0.5 h-1.5 w-1.5 rounded-full bg-mint animate-breathe" />
          </div>
          <div>
            <div className="text-[13px] font-semibold tracking-[0.14em] text-white">NEXGEN</div>
            <div className="text-[9.5px] font-medium tracking-[0.28em] text-slate-500">AIOPS</div>
          </div>
        </div>

        <div className="mx-4 mb-3 rounded-xl border border-line bg-ink-800/70 px-3 py-2.5">
          <div className="flex items-center justify-between">
            <span className="label">Tenant</span>
            <span className="h-1.5 w-1.5 rounded-full bg-mint" />
          </div>
          <div className="mt-1 truncate text-[11.5px] font-medium text-slate-200">{user?.tenant_name || user?.tenant_id}</div>
          <div className="mt-0.5 truncate text-[10px] text-slate-500">{user?.role?.replace('_', ' ')}</div>
        </div>

        <nav className="flex-1 space-y-4 overflow-y-auto px-3 pb-4">
          {GROUPS.map(g => (
            <div key={g.title}>
              <div className="px-2 pb-1.5 text-[9.5px] font-bold uppercase tracking-[0.18em] text-slate-600">{g.title}</div>
              <div className="space-y-0.5">
                {g.items.map(it => (
                  <NavLink key={it.to} to={it.to} end={it.to === '/'}
                    className={({ isActive }) => `group flex items-center gap-2.5 rounded-lg px-2.5 py-[7px] text-[12px] transition-colors ${isActive ? 'bg-sky/12 text-white' : 'text-slate-400 hover:bg-white/[0.045] hover:text-slate-200'}`}>
                    {({ isActive }) => (
                      <>
                        <span className={`w-3.5 text-center text-[11px] ${isActive ? 'text-sky' : 'text-slate-600 group-hover:text-slate-400'}`}>{it.icon}</span>
                        <span className="truncate">{it.label}</span>
                        {isActive && <span className="ml-auto h-1 w-1 rounded-full bg-sky" />}
                      </>
                    )}
                  </NavLink>
                ))}
              </div>
            </div>
          ))}
        </nav>

        <div className="border-t border-line px-4 py-3">
          <div className="flex items-center justify-between text-[10px] text-slate-500">
            <span className="flex items-center gap-1.5">
              <span className={`h-1.5 w-1.5 rounded-full ${connected ? 'bg-mint animate-breathe' : 'bg-rose'}`} />
              {connected ? 'stream live' : 'reconnecting'}
            </span>
            <span className="mono">t{tick?.tick ?? 0}</span>
          </div>
          <div className="mt-1 truncate text-[10px] text-slate-600">UTC {tick?.utc?.slice(11, 19) || '--:--:--'}</div>
        </div>
      </aside>

      {/* Main */}
      <div className="flex min-h-screen w-full flex-col lg:pl-[248px]">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-3 border-b border-line bg-ink-950/85 px-5 backdrop-blur">
          <button className="btn btn-ghost btn-xs lg:hidden" onClick={() => setMobile(v => !v)}>☰</button>
          <div className="hidden items-center gap-2 sm:flex">
            <span className="chip border-amber/25 bg-amber/10 text-amber">SIMULATED DATA</span>
            <span className="chip">two-tier · local redaction</span>
            {tick && tick.critical > 0 && <span className="chip border-rose/30 bg-rose/10 text-rose">{tick.critical} critical</span>}
          </div>
          <div className="ml-auto flex items-center gap-2">
            <button className="btn btn-primary" onClick={() => setDemoOpen(true)}>
              <span className="h-1.5 w-1.5 rounded-full bg-sky animate-breathe" /> Live demo
            </button>
            <div className="hidden items-center gap-2 rounded-lg border border-line bg-ink-800 px-2.5 py-1.5 md:flex">
              <div className="grid h-6 w-6 place-items-center rounded-md bg-gradient-to-br from-violet to-sky text-[10px] font-bold text-ink-950">
                {(user?.name || 'U').slice(0, 1)}
              </div>
              <div className="leading-tight">
                <div className="text-[11px] font-medium text-slate-200">{user?.name}</div>
                <div className="text-[9.5px] text-slate-500">{user?.email}</div>
              </div>
            </div>
            <button className="btn" onClick={logout}>Sign out</button>
          </div>
        </header>

        <main className="flex-1 px-5 py-6 lg:px-7">
          <Outlet />
        </main>

        <footer className="border-t border-line px-6 py-4 text-[10.5px] text-slate-600">
          NEXGEN AIOPS · privacy-first two-tier observability · every metric shown is synthetic and generated by the built-in simulator ·
          <span className="ml-l text-slate-500"> last tick {timeAgo(tick?.utc || null)}</span>
        </footer>
      </div>

      {/* Demo drawer */}
      {demoOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-ink-950/70 backdrop-blur-sm" onClick={() => setDemoOpen(false)}>
          <div className="h-full w-full max-w-[420px] overflow-y-auto border-l border-line bg-ink-900 p-5" onClick={e => e.stopPropagation()}>
            <div className="flex items-start justify-between">
              <div>
                <div className="label">Live demonstration</div>
                <h3 className="mt-1 text-[16px] font-semibold text-white">Scenario controls</h3>
                <p className="mt-1 text-[11.5px] leading-relaxed text-slate-500">
                  Triggering a scenario re-runs the collector pipeline immediately. Dashboards, alerts and incidents update on the next stream tick.
                </p>
              </div>
              <button className="btn btn-ghost btn-xs" onClick={() => setDemoOpen(false)}>✕</button>
            </div>
            <div className="mt-4 space-y-1.5">
              {DEMO_SCENARIOS.map(([key, label, icon]) => {
                const on = active.includes(key)
                return (
                  <button key={key} onClick={() => trigger(key)} disabled={busy === key}
                    className={`flex w-full items-center gap-3 rounded-xl border px-3 py-2.5 text-left transition-colors ${on ? 'border-sky/50 bg-sky/10' : 'border-line bg-ink-800 hover:border-sky/30'} ${busy === key ? 'opacity-60' : ''}`}>
                    <span className={`grid h-7 w-7 place-items-center rounded-lg text-[12px] ${on ? 'bg-sky/20 text-sky' : 'bg-ink-700 text-slate-400'}`}>{icon}</span>
                    <span className="flex-1 text-[12px] font-medium text-slate-200">{label}</span>
                    {on ? <span className="text-[9.5px] font-bold uppercase tracking-wider text-sky">active</span>
                      : <span className="text-[10px] text-slate-600">trigger</span>}
                  </button>
                )
              })}
            </div>
            <div className="mt-5 rounded-xl border border-line bg-ink-800/60 p-3 text-[10.5px] leading-relaxed text-slate-500">
              <b className="text-slate-300">Note on provenance.</b> All telemetry in this build is synthetic, produced by the in-process simulator.
              The organiser's shared stream has not been connected or tested in this environment.
            </div>
            <button className="btn mt-3 w-full" onClick={() => post('/api/demo/tick').then(loadScenarios)}>Force one ingest tick</button>
          </div>
        </div>
      )}
    </div>
  )
}
