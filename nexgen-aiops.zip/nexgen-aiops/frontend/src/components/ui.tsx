import React from 'react'
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis,
} from 'recharts'

export const STATE_COLOR: Record<string, string> = {
  Excellent: '#22c55e', Good: '#38bdf8', Fair: '#f59e0b', Poor: '#f43f5e',
}
export const SEV_COLOR: Record<string, string> = {
  critical: '#f43f5e', warning: '#f59e0b', info: '#38bdf8',
}

export function Card({ children, className = '' }: any) {
  return <div className={`card animate-fade-up ${className}`}>{children}</div>
}

export function CardHead({ title, sub, right }: any) {
  return (
    <div className="card-head">
      <div>
        <div className="card-title">{title}</div>
        {sub && <div className="card-sub mt-0.5">{sub}</div>}
      </div>
      {right}
    </div>
  )
}

export function PageHead({ title, sub, right, eyebrow }: any) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
      <div>
        {eyebrow && <div className="label mb-1.5">{eyebrow}</div>}
        <h1 className="text-[22px] font-semibold tracking-tight text-white">{title}</h1>
        {sub && <p className="mt-1 max-w-3xl text-[12.5px] leading-relaxed text-slate-400">{sub}</p>}
      </div>
      {right && <div className="flex flex-wrap items-center gap-2">{right}</div>}
    </div>
  )
}

export function StateBadge({ state, score }: { state: string; score?: number }) {
  const c = STATE_COLOR[state] || '#64748b'
  return (
    <span className="inline-flex items-center gap-1.5 rounded-md px-2 py-0.5 text-[11px] font-semibold"
      style={{ color: c, background: `${c}14`, border: `1px solid ${c}33` }}>
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: c }} />
      {state}{score !== undefined && <span className="opacity-60">· {score}</span>}
    </span>
  )
}

export function SevBadge({ severity }: { severity: string }) {
  const c = SEV_COLOR[severity] || '#64748b'
  return (
    <span className="inline-flex items-center rounded px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wider"
      style={{ color: c, background: `${c}18`, border: `1px solid ${c}33` }}>{severity}</span>
  )
}

export function Kpi({ label, value, unit, hint, trend, accent = '#38bdf8', icon, delta }: any) {
  return (
    <div className="card card-pad animate-fade-up">
      <div className="flex items-start justify-between">
        <div className="label">{label}</div>
        {icon && <div className="text-[15px] opacity-70">{icon}</div>}
      </div>
      <div className="mt-2 flex items-end gap-1.5">
        <span className="kpi" style={{ color: accent }}>{value}</span>
        {unit && <span className="mb-1 text-[11px] font-medium text-slate-500">{unit}</span>}
      </div>
      <div className="mt-1.5 flex items-center gap-2">
        {delta !== undefined && (
          <span className="text-[10.5px] font-semibold" style={{ color: delta >= 0 ? '#22c55e' : '#f43f5e' }}>
            {delta >= 0 ? '▲' : '▼'} {Math.abs(delta)}%
          </span>
        )}
        {hint && <span className="text-[10.5px] text-slate-500">{hint}</span>}
      </div>
      {trend && <div className="mt-2 h-8"><Sparkline data={trend} color={accent} /></div>}
    </div>
  )
}

export function Sparkline({ data, color = '#38bdf8', height = 32 }: any) {
  if (!data || data.length === 0) return <div style={{ height }} />
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data} margin={{ top: 2, right: 0, bottom: 0, left: 0 }}>
        <defs>
          <linearGradient id={`spark-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.4} />
            <stop offset="100%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <Area type="monotone" dataKey="v" stroke={color} strokeWidth={1.6} fill={`url(#spark-${color.replace('#', '')})`} isAnimationActive={false} />
      </AreaChart>
    </ResponsiveContainer>
  )
}

const tooltipStyle = {
  background: '#0b1220', border: '1px solid #1a2637', borderRadius: 10,
  fontSize: 11.5, color: '#e2e8f0', padding: '6px 10px',
}

export function TrendChart({ data, color = '#38bdf8', height = 210, unit = '', label = 'value', yDomain }: any) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <AreaChart data={data || []} margin={{ top: 8, right: 10, bottom: 0, left: -18 }}>
        <defs>
          <linearGradient id={`grad-${color.replace('#', '')}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity={0.35} />
            <stop offset="100%" stopColor={color} stopOpacity={0.02} />
          </linearGradient>
        </defs>
        <CartesianGrid stroke="#182234" strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="t" tick={{ fontSize: 9.5 }} interval="preserveStartEnd" minTickGap={28} stroke="#213045" />
        <YAxis tick={{ fontSize: 9.5 }} stroke="#213045" domain={yDomain} width={44} />
        <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => [`${v}${unit}`, label]} />
        <Area type="monotone" dataKey="v" stroke={color} strokeWidth={1.9} fill={`url(#grad-${color.replace('#', '')})`} isAnimationActive={false} dot={false} />
      </AreaChart>
    </ResponsiveContainer>
  )
}

export function MultiChart({ series, height = 240, unit = '' }: { series: { name: string; color: string; data: any[] }[]; height?: number; unit?: string }) {
  const len = Math.max(0, ...series.map(s => s.data?.length || 0))
  const merged = Array.from({ length: len }).map((_, i) => {
    const row: any = { t: series[0]?.data?.[i]?.t || `${i}` }
    series.forEach(s => { row[s.name] = s.data?.[i]?.v })
    return row
  })
  return (
    <ResponsiveContainer width="100%" height={height}>
      <LineChart data={merged} margin={{ top: 8, right: 10, bottom: 0, left: -18 }}>
        <CartesianGrid stroke="#182234" strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="t" tick={{ fontSize: 9.5 }} minTickGap={30} stroke="#213045" />
        <YAxis tick={{ fontSize: 9.5 }} stroke="#213045" width={44} />
        <Tooltip contentStyle={tooltipStyle} />
        <Legend wrapperStyle={{ fontSize: 10.5, color: '#94a3b8' }} />
        {series.map(s => (
          <Line key={s.name} type="monotone" dataKey={s.name} stroke={s.color} strokeWidth={1.8} dot={false} isAnimationActive={false} />
        ))}
      </LineChart>
    </ResponsiveContainer>
  )
}

export function Bars({ data, xKey, yKey, color = '#38bdf8', height = 200, unit = '' }: any) {
  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={data} margin={{ top: 8, right: 10, bottom: 0, left: -18 }}>
        <CartesianGrid stroke="#182234" strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey={xKey} tick={{ fontSize: 9.5 }} stroke="#213045" />
        <YAxis tick={{ fontSize: 9.5 }} stroke="#213045" width={40} />
        <Tooltip contentStyle={tooltipStyle} formatter={(v: any) => [`${v}${unit}`, yKey]} />
        <Bar dataKey={yKey} radius={[4, 4, 0, 0]}>
          {data?.map((d: any, i: number) => (
            <Cell key={i} fill={d.color || color} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  )
}

export function Progress({ value, color = '#38bdf8', max = 100 }: any) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100))
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-ink-600">
      <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: color }} />
    </div>
  )
}

export function Skeleton({ h = 120 }: { h?: number }) {
  return <div className="animate-pulse rounded-2xl border border-line bg-ink-800/60" style={{ height: h }} />
}

export function Loading({ rows = 3 }: { rows?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: rows }).map((_, i) => <Skeleton key={i} h={108} />)}
    </div>
  )
}

export function Empty({ text = 'No data yet. Telemetry is being collected.' }: any) {
  return <div className="flex flex-col items-center justify-center py-12 text-center">
    <div className="mb-2 text-2xl opacity-40">◇</div>
    <div className="text-[12px] text-slate-500">{text}</div>
  </div>
}

export function ErrorNote({ message }: { message: string }) {
  return (
    <div className="rounded-xl border border-rose/30 bg-rose/10 px-4 py-3 text-[12px] text-rose">
      {message}
    </div>
  )
}

export function Table({ head, children }: any) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse text-left">
        <thead>
          <tr className="border-b border-line">
            {head.map((h: string) => (
              <th key={h} className="whitespace-nowrap px-4 py-2.5 text-[10px] font-semibold uppercase tracking-[0.12em] text-slate-500">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  )
}

export function Td({ children, className = '' }: any) {
  return <td className={`whitespace-nowrap border-b border-line/50 px-4 py-2.5 text-[12px] text-slate-300 ${className}`}>{children}</td>
}

export function Json({ value, max = 320 }: { value: any; max?: number }) {
  const text = typeof value === 'string' ? value : JSON.stringify(value, null, 2)
  const shown = text.length > max * 12 ? text.slice(0, max * 12) + '\n…' : text
  return (
    <pre className="mono max-h-[320px] overflow-auto rounded-lg border border-line bg-ink-950/80 p-3 leading-relaxed text-slate-400">
      {shown}
    </pre>
  )
}

export function EnvTag() {
  return (
    <span className="chip border-amber/30 bg-amber/10 text-amber">SIMULATED TELEMETRY</span>
  )
}

export function SectionTitle({ children, hint }: any) {
  return (
    <div className="mb-3 flex items-center justify-between">
      <h2 className="text-[13px] font-semibold tracking-wide text-slate-200">{children}</h2>
      {hint && <span className="text-[11px] text-slate-500">{hint}</span>}
    </div>
  )
}
