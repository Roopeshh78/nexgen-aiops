"""Automated tests — every assertion here exercises real code paths, no mocks of the logic under test."""
import os
import sys

import pytest
from fastapi.testclient import TestClient

os.environ["NEXGEN_SIM"] = "0"
os.environ["NEXGEN_DB_URL"] = "sqlite:///./test_nexgen.db"

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

if os.path.exists("test_nexgen.db"):
    os.remove("test_nexgen.db")

from app import collector, simulator  # noqa: E402
from app.db import Base, SessionLocal, engine  # noqa: E402
from app.main import app  # noqa: E402

Base.metadata.create_all(bind=engine)


@pytest.fixture(scope="session")
def db():
    s = SessionLocal()
    simulator.seed_database(s)
    yield s
    s.close()


@pytest.fixture(scope="session", autouse=True)
def _seed():
    """Seed once for the whole session so no test depends on execution order."""
    s = SessionLocal()
    simulator.seed_database(s)
    s.close()
    yield


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c


def auth(client, email="analyst@acme.io"):
    r = client.post("/api/auth/login", json={"email": email, "password": "NexGen#2026"})
    assert r.status_code == 200, r.text
    return {"Authorization": f"Bearer {r.json()['token']}"}


# ------------------------------------------------------------------ auth & tenancy
def test_login_rejects_bad_password(client):
    r = client.post("/api/auth/login", json={"email": "analyst@acme.io", "password": "wrong"})
    assert r.status_code == 401


def test_login_sets_tenant_from_user_record(client):
    r = client.post("/api/auth/login", json={"email": "ops@northwind.io", "password": "NexGen#2026"})
    assert r.status_code == 200
    assert r.json()["user"]["tenant_id"] == "t_northwind"


def test_unauthenticated_request_blocked(client):
    assert client.get("/api/overview").status_code == 401


def test_cross_tenant_access_denied(client):
    h = auth(client, "analyst@acme.io")
    r = client.get("/api/overview?tenant_id=t_northwind", headers=h)
    assert r.status_code == 403


def test_platform_admin_can_scope_other_tenant(client):
    h = auth(client, "admin@acme.io")
    r = client.get("/api/overview?tenant_id=t_northwind", headers=h)
    assert r.status_code == 200
    assert r.json()["tenant"]["id"] == "t_northwind"


# ------------------------------------------------------------------ privacy pipeline
def test_redaction_strips_credentials_and_pii():
    raw = [{
        "event_id": "e1", "host": "h1", "metric": "cpu_pct", "value": 91.0, "unit": "%",
        "raw_log": "user=ops@acme.io password=Sup3rS3cret! token=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJvcHMifQ.abcd1234",
        "credentials": {"password": "Sup3rS3cret!", "api_key": "sk-live-123"},
        "customer_email": "oncall@acme.io", "ip_address": "10.4.2.21",
    }]
    env = collector.build_envelope("t_acme", "col_test", raw)
    body = env["body"]
    assert "Sup3rS3cret" not in body
    assert "oncall@acme.io" not in body
    assert "10.4.2.21" not in body
    assert "sk-live-123" not in body
    assert env["stage_counts"]["redactions"] > 0


def test_allow_list_is_enforced_structurally():
    raw = [{"event_id": "e2", "host": "h1", "service": "svc", "metric": "cpu_pct",
            "value": 55.0, "unit": "%", "secret_field": "leak", "stack_trace": "trace"}]
    env = collector.build_envelope("t_acme", "col_test", raw)
    event = env["payload"]["events"][0]
    for key in event:
        assert key in collector.ALLOWED_FIELDS, f"{key} should not be egress-capable"
    assert "secret_field" not in event
    assert "stack_trace" not in event


def test_forbidden_field_blocked_by_ingest_api(client, db):
    h = auth(client, "admin@acme.io")
    r = client.post("/api/ingest", json={
        "collector_id": "col_k8s_prod", "tenant_id": "t_acme",
        "events": [{"event_id": "e_bad_1", "metric": "cpu_pct", "value": 40, "password": "hunter2"}],
    })
    assert r.status_code == 200
    assert r.json()["accepted"] == 0
    assert r.json()["rejected"][0]["reason"] == "forbidden_field"


def test_validate_endpoint_blocks_sensitive_payload(client):
    h = auth(client, "analyst@acme.io")
    r = client.post("/api/egress/validate", headers=h, json={
        "events": [{"event_id": "x", "host": "h", "metric": "cpu_pct", "value": 1, "password": "p"}]
    })
    assert r.status_code == 200
    assert r.json()["allowed_to_transmit"] is False


def test_validate_endpoint_passes_clean_payload(client):
    h = auth(client, "analyst@acme.io")
    r = client.post("/api/egress/validate", headers=h, json={
        "events": [{"event_id": "x", "host": "h", "metric": "cpu_pct", "value": 41.0,
                    "unit": "%", "schema_version": "1.4", "severity": "info"}]
    })
    assert r.json()["allowed_to_transmit"] is True


def test_privacy_inspect_runs_real_pipeline(client):
    h = auth(client, "analyst@acme.io")
    r = client.post("/api/privacy/inspect", headers=h, json={
        "event_id": "e3", "host": "h", "metric": "cpu_pct", "value": 70,
        "raw_log": "password=abc123", "customer_email": "a@b.com",
    })
    assert r.status_code == 200
    out = r.json()
    assert "password" not in str(out["output"])
    assert "a@b.com" not in str(out["output"])


# ------------------------------------------------------------------ buffering & dedupe
def test_buffer_dedupes_by_event_id():
    buf = collector.EventBuffer()
    ev = {"event_id": "dup1", "observed_at": "2026-11-20T00:00:00Z", "sequence": 1}
    buf.enqueue([ev])
    buf.enqueue([ev])
    assert buf.depth() == 1
    assert buf.stats()["duplicates_suppressed"] == 1


def test_buffer_sorts_out_of_order_events():
    buf = collector.EventBuffer()
    buf.enqueue([
        {"event_id": "b", "observed_at": "2026-11-20T00:00:10Z", "sequence": 2},
        {"event_id": "a", "observed_at": "2026-11-20T00:00:05Z", "sequence": 1},
    ])
    batch = buf.take(10)
    assert [e["event_id"] for e in batch] == ["a", "b"]


def test_buffer_bounds_capacity_and_counts_drops():
    buf = collector.EventBuffer(capacity=3)
    buf.enqueue([{"event_id": f"e{i}", "observed_at": f"2026-11-20T00:00:0{i}Z"} for i in range(6)])
    assert buf.depth() == 3
    assert buf.stats()["dropped"] == 3


def test_aggregation_reduces_event_count():
    raw = [{"event_id": f"e{i}", "host": "h1", "service": "svc", "metric": "cpu_pct",
            "value": 50 + i, "unit": "%"} for i in range(10)]
    env = collector.build_envelope("t_acme", "col", raw)
    assert env["stage_counts"]["approved"] == 1  # collapsed to one (host, metric) aggregate


# ------------------------------------------------------------------ AIOps maths
def test_health_label_uses_exact_four_states():
    assert simulator.aiops.health_label(92) == "Excellent"
    assert simulator.aiops.health_label(75) == "Good"
    assert simulator.aiops.health_label(55) == "Fair"
    assert simulator.aiops.health_label(21) == "Poor"


def test_forecast_detects_rising_trend():
    f = simulator.aiops.linear_forecast([10, 12, 14, 16, 18, 20, 22, 24])
    assert f["available"] is True
    assert f["trend"] == "rising"
    assert f["slope_per_step"] > 1.9


def test_forecast_refuses_insufficient_history():
    assert simulator.aiops.linear_forecast([42])["available"] is False


def test_zscore_flags_deviation():
    stats = simulator.aiops.baseline_stats([10, 10, 10, 10, 10])
    assert simulator.aiops.z_score(10, stats) == 0.0


def test_explanation_has_all_four_parts():
    e = simulator.aiops.explain({"metric": "cpu_pct", "value": 95, "host": "h1",
                                 "z_score": 3.2, "deviation_pct": 41.0})
    for key in ("what_happened", "why_detected", "contributing_signals", "recommended_action"):
        assert e[key]
    assert 0 < e["confidence"] <= 0.97


# ------------------------------------------------------------------ stale telemetry
def test_stale_collector_is_poor_not_healthy(client, db):
    from datetime import timedelta
    from app.db import utcnow
    from app.models import Collector
    c = db.query(Collector).filter(Collector.id == "col_edge_gw").first()
    c.last_seen = utcnow() - timedelta(seconds=600)
    db.commit()
    h = auth(client, "admin@acme.io")
    r = client.get("/api/overview", headers=h)
    row = [x for x in r.json()["health_states"] if x["host"] == c.host][0]
    assert row["state"] == "Poor"
    assert row["stale"] is True
    c.last_seen = utcnow()
    db.commit()


# ------------------------------------------------------------------ scenarios & tick
def test_scenario_triggers_dashboard_change(client):
    h = auth(client, "admin@acme.io")
    before = client.get("/api/overview", headers=h).json()
    r = client.post("/api/scenarios/high_cpu", headers=h)
    assert r.status_code == 200
    after = client.get("/api/overview", headers=h).json()
    assert after["kpis"]["telemetry_events"] >= before["kpis"]["telemetry_events"]
    assert "high_cpu" in after["scenarios"]


def test_multi_alert_scenario_creates_incident(client, db):
    h = auth(client, "admin@acme.io")
    client.post("/api/scenarios/multi_alert", headers=h)
    for _ in range(3):
        client.post("/api/demo/tick", headers=h)
    alerts = client.get("/api/alerts?state=open", headers=h).json()
    incidents = client.get("/api/incidents", headers=h).json()
    assert len(alerts["alerts"]) > 0
    assert len(incidents["incidents"]) > 0


def test_recovery_resets_collectors(client):
    h = auth(client, "admin@acme.io")
    client.post("/api/scenarios/collector_offline", headers=h)
    r = client.post("/api/scenarios/recovery", headers=h)
    assert r.status_code == 200
    env = client.get("/api/collectors", headers=h).json()
    assert all(c["status"] == "online" for c in env["collectors"])


def test_alert_ack_writes_audit_entry(client):
    h = auth(client, "admin@acme.io")
    alerts = client.get("/api/alerts?state=open", headers=h).json()["alerts"]
    if not alerts:
        client.post("/api/scenarios/high_cpu", headers=h)
        alerts = client.get("/api/alerts?state=open", headers=h).json()["alerts"]
    assert alerts
    aid = alerts[0]["id"]
    r = client.post(f"/api/alerts/{aid}/ack", headers=h)
    assert r.json()["state"] == "acknowledged"
    logs = client.get("/api/audit", headers=h).json()["logs"]
    assert any(l["action"] == "alert.acknowledge" for l in logs)


def test_audit_chain_verifies(client):
    h = auth(client, "admin@acme.io")
    chain = client.get("/api/audit", headers=h).json()["chain"]
    assert chain["valid"] is True
    assert chain["checked"] > 0


# ------------------------------------------------------------------ API surface
@pytest.mark.parametrize("path", [
    "/api/overview", "/api/infra", "/api/network", "/api/app", "/api/security", "/api/cloud",
    "/api/distributed", "/api/aiops/modules", "/api/aiops/anomalies", "/api/aiops/correlations",
    "/api/aiops/noise", "/api/alerts", "/api/incidents", "/api/predict?metric=cpu_pct",
    "/api/capacity", "/api/collectors", "/api/privacy/policy", "/api/egress",
    "/api/tenants", "/api/audit", "/api/recommendations", "/api/scenarios", "/api/health",
])
def test_endpoint_returns_200(client, path):
    h = auth(client, "analyst@acme.io")
    r = client.get(path, headers=h)
    assert r.status_code == 200, f"{path} -> {r.status_code} {r.text[:200]}"


def test_incident_status_validation(client):
    h = auth(client, "admin@acme.io")
    incs = client.get("/api/incidents", headers=h).json()["incidents"]
    if incs:
        r = client.patch(f"/api/incidents/{incs[0]['id']}", headers=h, json={"status": "bogus"})
        assert r.status_code == 400


def test_websocket_streams_tick(client):
    token = client.post("/api/auth/login", json={"email": "analyst@acme.io", "password": "NexGen#2026"}).json()["token"]
    with client.websocket_connect(f"/ws?token={token}") as ws:
        msg = ws.receive_json()
        assert msg["type"] in ("tick", "error")
